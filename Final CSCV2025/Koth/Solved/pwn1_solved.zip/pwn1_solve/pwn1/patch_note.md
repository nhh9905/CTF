# Note patch
- Max 50 bytes changed
- Not change size of binary
- Not change program logic
- Patched file upload: file_manager.zip containing only one file named file_manager