from pathlib import Path

src = Path("vault")
dst = Path("vault_elf")

data = bytearray(src.read_bytes())

def put(off, size, val):
    data[off:off+size] = int(val).to_bytes(size, "little")

put(0x28, 8, 0)
put(0x3a, 2, 0)
put(0x3c, 2, 0)
put(0x3e, 2, 0)

dst.write_bytes(data)
