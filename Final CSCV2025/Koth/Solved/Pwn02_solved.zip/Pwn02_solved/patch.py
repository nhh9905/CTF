import ida_bytes
import ida_name
import ida_funcs
import ida_search
import ida_kernwin
import ida_ida

BADADDR = ida_ida.BADADDR

# We fix the shared "cups+type" 16-bit field bug used by exp.py.
# In sub_1E70 (Feed) and sub_1E9A (Poop) the code currently does:
#
#   movzx   edx, word ptr [rdx]   ; load 16-bit cups+type
#   ...
#   add     edx, ecx / sub edx, ecx
#   mov     [rax], dx             ; store both cups and type back
#
# This lets large feeds change the type byte at [this+9].
#
# The patch keeps the intended logic ("add/sub cups") but restricts it
# to the low 8 bits and writes back only that low byte, leaving type
# at [this+9] untouched.
#
# Concretely:
#   - movzx edx, word ptr [rdx]  -> movzx edx, byte ptr [rdx]
#       (0F B7 12)               -> (0F B6 12)
#   - mov [rax], dx              -> mov [rax], dl
#       (66 89 10)               -> (66 88 10)  ; 66 is a harmless prefix here
#
# This changes 2 bytes per function, 4 bytes total.

def patch_cups_logic(func_name):
    ea = ida_name.get_name_ea_simple(func_name)
    if ea == BADADDR:
        ida_kernwin.msg(f"[patch] {func_name}: not found, nothing patched.\n")
        return False

    f = ida_funcs.get_func(ea)
    if not f:
        ida_kernwin.msg(f"[patch] {func_name}: not a function, nothing patched.\n")
        return False

    start, end = f.start_ea, f.end_ea
    ok = True

    # 1) movzx edx, word ptr [rdx]  -> movzx edx, byte ptr [rdx]
    ea_movzx = ida_search.find_binary(start, end, "0F B7 12", 16, ida_search.SEARCH_DOWN)
    if ea_movzx == BADADDR:
        ida_kernwin.msg(f"[patch] {func_name}: pattern '0F B7 12' not found.\n")
        ok = False
    else:
        # change B7 -> B6
        ida_bytes.patch_byte(ea_movzx + 1, 0xB6)

    # 2) mov [rax], dx  -> mov [rax], dl
    ea_movdx = ida_search.find_binary(start, end, "66 89 10", 16, ida_search.SEARCH_DOWN)
    if ea_movdx == BADADDR:
        ida_kernwin.msg(f"[patch] {func_name}: pattern '66 89 10' not found.\n")
        ok = False
    else:
        # change 89 -> 88 (keep 66 prefix so instruction size stays 3 bytes)
        ida_bytes.patch_byte(ea_movdx + 1, 0x88)

    if ok:
        ida_kernwin.msg(f"[patch] {func_name}: cups logic patched (2 bytes changed).\n")
    return ok


def main():
    ok1 = patch_cups_logic("sub_1E70")  # Feed
    ok2 = patch_cups_logic("sub_1E9A")  # Poop

    if ok1 and ok2:
        ida_kernwin.msg(
            "[patch] Done: Feed/Poop no longer modify the type byte.\n"
            "[patch] Total bytes changed: 4 (<< 50), binary size unchanged.\n"
            "[patch] You can now apply patches to the input file and zip it as chall.zip.\n"
        )
    else:
        ida_kernwin.msg("[patch] WARNING: One or both functions failed to patch; check patterns.\n")


if __name__ == "__main__":
    main()