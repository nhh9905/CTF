import idautils
import ida_bytes
import ida_name
import ida_funcs
import idc

# Use the stricter limit from patch-note.md (25 bytes) even though the
# file_manager-specific note allows up to 50 bytes.
MAX_PATCH_BYTES = 25
patch_count = 0


def base_name(name: str) -> str:
    """Strip GLIBC versioning and leading underscore."""
    if not name:
        return ""
    if "@" in name:
        name = name.split("@", 1)[0]
    if name.startswith("_"):
        name = name[1:]
    return name


def patch_byte(ea: int, val: int) -> None:
    """Patch a single byte and track how many bytes we changed."""
    global patch_count
    old = ida_bytes.get_byte(ea)
    if old == val:
        return
    ida_bytes.patch_byte(ea, val)
    patch_count += 1


def patch_dword(ea: int, val: int) -> None:
    """Patch a 32-bit little-endian dword and track bytes."""
    global patch_count
    val &= 0xFFFFFFFF
    old = ida_bytes.get_dword(ea)
    if old == val:
        return
    ida_bytes.patch_dword(ea, val)
    patch_count += 4


def find_find_format():
    """
    Locate the 'find  %s  -name '%s' 2>/dev/null' format string in .rodata.

    Works even if it's already patched to "find '%s' -name '%s' 2>/dev/null".
    """
    target_unpatched = "find  %s  -name '%s' 2>/dev/null"
    target_patched = "find '%s' -name '%s' 2>/dev/null"

    s_obj = idautils.Strings()
    # Make sure we are scanning C-style strings
    try:
        s_obj.setup(strtypes=idc.STRTYPE_C)
    except Exception:
        # Old IDA: setup() may not exist; it's fine, defaults usually OK
        pass

    ea_unpatched = idc.BADADDR
    ea_patched = idc.BADADDR
    for s in s_obj:
        text = str(s)
        if text == target_unpatched:
            ea_unpatched = s.ea
            break
        if text == target_patched and ea_patched == idc.BADADDR:
            ea_patched = s.ea

    if ea_unpatched != idc.BADADDR:
        return ea_unpatched, target_unpatched
    if ea_patched != idc.BADADDR:
        return ea_patched, target_patched

    return idc.BADADDR, None


def patch_find_format():
    """
    Harden cmd_find:

        "find  %s  -name '%s' 2>/dev/null"
    ->  "find '%s' -name '%s' 2>/dev/null"

    This quotes user_path and kills the username command injection.
    """
    ea, current = find_find_format()
    if ea == idc.BADADDR:
        print("[*] find() format string not found, skipping that patch")
        return

    target_unpatched = "find  %s  -name '%s' 2>/dev/null"
    target_patched = "find '%s' -name '%s' 2>/dev/null"

    if current == target_patched:
        print("[*] find() format string already patched at 0x%X" % ea)
        return

    if current != target_unpatched:
        print("[!] Unexpected find() format contents at 0x%X: %r" % (ea, current))
        print("[!] Not patching to avoid corrupting an unknown build.")
        return

    if len(target_unpatched) != len(target_patched):
        print("[!] Length mismatch on format strings, aborting")
        return

    for i, ch in enumerate(target_patched):
        patch_byte(ea + i, ord(ch))

    print("[+] Patched find() format string at 0x%X" % ea)


def find_import_by_basename(symbol: str) -> int:
    """
    Find the address of an imported function by base name (e.g. 'printf', 'puts'),
    ignoring GLIBC versioning and leading underscores.
    """
    symbol = symbol.lower()
    for ea, nm in idautils.Names():
        if base_name(nm).lower() == symbol:
            return ea
    return idc.BADADDR


def patch_cmd_cat_printf_to_puts():
    """
    In cmd_cat, find the single printf(line) call and retarget it to puts(line).

    We identify it as:
      - a call whose target base name is 'printf'
      - within the last few instructions, RDI is loaded from an [rbp+...] stack
        location (the line buffer), not from .rodata.
    """
    cmd_cat_ea = idc.get_name_ea_simple("cmd_cat")
    if cmd_cat_ea == idc.BADADDR:
        print("[*] cmd_cat not found, skipping printf->puts patch")
        return

    puts_ea = find_import_by_basename("puts")
    if puts_ea == idc.BADADDR:
        print("[!] puts() import not found, cannot patch printf(line)")
        return

    func = ida_funcs.get_func(cmd_cat_ea)
    if not func:
        print("[!] Failed to get func_t for cmd_cat")
        return

    patched = False

    for ea in idautils.FuncItems(cmd_cat_ea):
        if idc.print_insn_mnem(ea) != "call":
            continue

        # Direct near calls use a rel32 target; get_operand_value will give us
        # the absolute target address.
        target = idc.get_operand_value(ea, 0)
        if target == idc.BADADDR:
            continue

        nm = ida_name.get_name(target)
        if base_name(nm) != "printf":
            continue

        # Look back a few instructions for something like:
        #   lea rdi, [rbp+format]    ; line buffer on stack
        # (and *not* a lea rdi, aSomeString).
        cur = ea
        stack_ref = False
        for _ in range(6):
            cur = idc.prev_head(cur)
            if cur == idc.BADADDR or not ida_funcs.func_contains(func, cur):
                break
            mnem = idc.print_insn_mnem(cur)
            if mnem not in ("lea", "mov"):
                continue
            op0 = idc.print_operand(cur, 0)
            # We want stack-based operands like [rbp-620h] or [rbp+var_620]
            if "rbp" in op0 and "[" in op0:
                stack_ref = True
                break

        if not stack_ref:
            # This is almost certainly printf("Some literal\n").
            continue

        # At this point, we believe we found the printf(line) from the cat loop.
        # Verify it's a direct rel32 call.
        if ida_bytes.get_byte(ea) != 0xE8:
            print("[!] call at 0x%X is not a direct rel32 call, skipping" % ea)
            continue

        new_rel = (puts_ea - (ea + 5)) & 0xFFFFFFFF
        old_rel = ida_bytes.get_dword(ea + 1)
        if old_rel == new_rel:
            print("[*] Call at 0x%X already points to puts()" % ea)
            patched = True
            break

        patch_dword(ea + 1, new_rel)
        print("[+] Patched cmd_cat printf(line) at 0x%X -> puts()" % ea)
        patched = True
        break

    if not patched:
        print("[*] No printf(line) call found in cmd_cat; maybe already patched?")


def main():
    global patch_count
    patch_count = 0

    print("[*] Starting binary patch for file_manager")

    patch_find_format()
    patch_cmd_cat_printf_to_puts()

    print("[*] Total bytes patched: %d" % patch_count)
    if patch_count > MAX_PATCH_BYTES:
        print("[!] WARNING: patched bytes (%d) exceed patch-note limit (%d)!"
              % (patch_count, MAX_PATCH_BYTES))
    else:
        print("[*] Patch is within patch-note byte limit (%d)" % MAX_PATCH_BYTES)


if __name__ == "__main__":
    main()