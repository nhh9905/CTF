# Run this inside IDA (File -> Script file...).
# It patches:
#   1) auth_user: fix token prefix bug.
#   2) INVALID_CHARS string: forbid ".." in image names.

import ida_bytes
import idc
import idautils

def patch_auth_user_token_len():
    """
    Inside auth_user, replace:
        call strlen
        mov  rdx, rax
    with:
        mov  edx, 40
        nop
        nop
        nop

    So we always compare 40 bytes in strncmp(stored, token, 40).
    """
    auth_ea = idc.get_name_ea_simple("auth_user")
    if auth_ea == idc.BADADDR:
        raise RuntimeError("auth_user not found")

    func_end = idc.find_func_end(auth_ea)
    call_ea = idc.BADADDR

    ea = auth_ea
    while ea != idc.BADADDR and ea < func_end:
        if idc.print_insn_mnem(ea) == "call":
            op = idc.print_operand(ea, 0)
            if "strlen" in op:  # matches 'strlen', '_strlen', 'strlen@plt', etc.
                call_ea = ea
                break
        ea = idc.next_head(ea, func_end)

    if call_ea == idc.BADADDR:
        raise RuntimeError("Could not find call to strlen inside auth_user")

    # Overwrite 8 bytes (originally: call rel32; mov rdx, rax)
    # with: mov edx, 40 ; nop ; nop ; nop
    ida_bytes.patch_byte(call_ea + 0, 0xBA)        # mov edx, imm32
    ida_bytes.patch_dword(call_ea + 1, 40)         # imm32 = 40
    ida_bytes.patch_byte(call_ea + 5, 0x90)        # nop
    ida_bytes.patch_byte(call_ea + 6, 0x90)        # nop
    ida_bytes.patch_byte(call_ea + 7, 0x90)        # nop

    print(f"[+] auth_user patched at 0x{call_ea:X}: strncmp now uses fixed length 40")

def patch_invalid_chars_to_dotdot():
    """
    Find the plain 'token.txt' string literal (not '/token.txt') and turn it into '..'.
    This changes INVALID_CHARS[0] from 'token.txt' to '..', so is_valid_image_name()
    rejects any filename containing '..'.
    """
    token_str_ea = idc.BADADDR

    for s in idautils.Strings():
        try:
            text = str(s)
        except UnicodeDecodeError:
            continue
        if text == "token.txt":
            token_str_ea = s.ea
            break

    if token_str_ea == idc.BADADDR:
        raise RuntimeError('"token.txt" string literal not found')

    # Overwrite "token.txt\\0" (10 bytes) with "..\\0\\0\\0\\0\\0\\0\\0"
    # New semantics: string is ".." (rest zero padding).
    data = b"..\x00" + b"\x00" * 7
    for i, b in enumerate(data):
        ida_bytes.patch_byte(token_str_ea + i, b)

    print(f"[+] INVALID_CHARS string at 0x{token_str_ea:X} changed from 'token.txt' to '..'")

def main():
    patch_auth_user_token_len()
    patch_invalid_chars_to_dotdot()
    print("[+] All patches applied (total changed bytes: 8 + 10 = 18 <= 25)")

if __name__ == "__main__":
    main()