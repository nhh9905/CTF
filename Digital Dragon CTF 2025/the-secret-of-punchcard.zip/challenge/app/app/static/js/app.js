let selectedFile = null;

// Navigation Functions
function showPage(pageId) {
    // Hide all pages
    document.querySelectorAll('.page').forEach(page => {
        page.style.display = 'none';
        page.classList.remove('active');
    });
    
    // Remove active class from all nav tabs
    document.querySelectorAll('.nav-tab').forEach(tab => {
        tab.classList.remove('active');
    });
    
    // Show selected page
    const selectedPage = document.getElementById(pageId);
    if (selectedPage) {
        selectedPage.style.display = 'block';
        selectedPage.classList.add('active');
    }
    
    // Add active class to the corresponding nav tab
    const navTabs = document.querySelectorAll('.nav-tab');
    navTabs.forEach(tab => {
        const onclick = tab.getAttribute('onclick');
        if (onclick && onclick.includes(`'${pageId}'`)) {
            tab.classList.add('active');
        }
    });
}

// Character Counter
function updateCharCounter() {
    const input = document.getElementById('text-input');
    const cardType = document.getElementById('card-type').value;
    const counter = document.getElementById('char-counter');
    const currentLength = input.value.length;
    const maxLength = cardType === 'STANDARD' ? 80 : 320;
    
    counter.textContent = `${currentLength}/${maxLength}`;
    
    if (currentLength > maxLength) {
        counter.style.color = '#dc3545';
        counter.textContent += ' - Vượt quá giới hạn!';
    } else if (currentLength > maxLength * 0.8) {
        counter.style.color = '#ffc107';
    } else {
        counter.style.color = '#6c757d';
    }
}

// File Handling
function triggerFileInput() {
    document.getElementById('file-input').click();
}

function handleFileSelect(event) {
    const file = event.target.files[0];
    if (file) {
        selectedFile = file;
        document.getElementById('file-name').textContent = file.name;
        document.getElementById('file-selected').style.display = 'block';
    }
}

// Create Punch Card Function
function createPunchCard() {
    const text = document.getElementById('text-input').value;
    const cardType = document.getElementById('card-type').value;
    
    if (!text.trim()) {
        alert('Vui lòng nhập văn bản để tạo thẻ đục lỗ!');
        return;
    }
    
    showCreateLoading();
    
    const requestData = {
        text: text,
        card_type: cardType
    };
    
    fetch('/create_punch_card', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify(requestData)
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            displayCreateResult(data);
        } else {
            displayCreateError(data.error || 'Có lỗi xảy ra khi tạo thẻ đục lỗ');
        }
    })
    .catch(error => {
        displayCreateError('Lỗi kết nối: ' + error.message);
    });
}

// Đọc thẻ đục lỗ
async function readPunchCard() {
    const fileInput = document.getElementById('file-input');
    const readBtn = document.getElementById('readBtn');
    const readCardType = document.getElementById('read-card-type');
    
    if (!selectedFile) {
        alert('Vui lòng chọn một tệp hình ảnh!');
        return;
    }
    
    const formData = new FormData();
    formData.append('image', selectedFile);
    formData.append('card_type', readCardType.value);
    
    showReadLoading();
    
    try {
        const response = await fetch('/read_punch_card', {
            method: 'POST',
            body: formData
        });
        
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }
        
        const result = await response.json();
        showReadResult(result);
    } catch (error) {
        console.error('Lỗi:', error);
        showReadResult({
            success: false,
            error: 'Lỗi kết nối: ' + error.message
        });
    }
}



// Display Functions
function showCreateLoading() {
    const resultDiv = document.getElementById('create-result');
    resultDiv.innerHTML = `
        <div class="loading">
            <div class="spinner"></div>
            <p>Đang tạo thẻ đục lỗ...</p>
        </div>
    `;
    resultDiv.style.display = 'block';
}

function showReadLoading() {
    const resultDiv = document.getElementById('read-result');
    const statusBadge = document.getElementById('read-status-badge');
    const resultContent = document.getElementById('read-result-content');
    
    resultDiv.style.display = 'block';
    
    if (statusBadge) {
        statusBadge.textContent = 'Đang xử lý...';
        statusBadge.className = 'status-badge loading';
    }
    
    if (resultContent) {
        resultContent.innerHTML = `
            <div class="loading">
                <div class="spinner"></div>
                <p>Đang đọc thẻ đục lỗ...</p>
            </div>
        `;
    }
}

function displayCreateResult(data) {
    const resultDiv = document.getElementById('create-result');
    let html = `
        <div class="result-success">
            <h3>✅ Tạo thẻ đục lỗ thành công!</h3>
            <div class="result-section">
                <h4>📝 Văn bản gốc:</h4>
                <p class="result-text">${escapeHtml(data.text)}</p>
            </div>
    `;

    if (data.visual_card) {
        html += `
            <div class="result-section">
                <h4>🎨 Thẻ đục lỗ:</h4>
                <img src="${data.visual_card}" alt="Thẻ đục lỗ" class="punch-card-image">
            </div>
        `;
    }
    
    if (data.download_url) {
        html += `
            <div class="result-section">
                <div class="download-section">
                    <a href="${data.download_url}" class="btn btn-download" download>
                        📥 Tải xuống
                    </a>
                </div>
            </div>
        `;
    }
    
    html += '</div>';
    resultDiv.innerHTML = html;
    resultDiv.style.display = 'block';
}

// Hiển thị kết quả đọc
function showReadResult(data) {
    const resultContainer = document.getElementById('read-result');
    const statusBadge = document.getElementById('read-status-badge');
    const resultContent = document.getElementById('read-result-content');
    
    console.log('DOM elements found:', {
        resultContainer: !!resultContainer,
        statusBadge: !!statusBadge,
        resultContent: !!resultContent
    });
    
    if (!resultContainer) {
        console.error('Could not find read-result element');
        return;
    }
    
    if (!statusBadge) {
        console.error('Could not find read-status-badge element');
        return;
    }
    
    if (!resultContent) {
        console.error('Could not find read-result-content element');
        return;
    }
    
    resultContainer.style.display = 'block';
    console.log('data.output:', data.output);
    
    if (data.success) {
        statusBadge.textContent = 'Thành công';
        statusBadge.className = 'status-badge success';
        
        let html = '';
        
        if (data.output) {
            html += `
                <div class="result-section">
                    <div class="code-block">${escapeHtml(data.output)}</div>
                </div>
            `;
        } else {
            html += `
                <div class="result-section">
                    <div class="code-block">Không có dữ liệu output từ server</div>
                </div>
            `;
        }
        
        resultContent.innerHTML = html;
    } else {
        statusBadge.textContent = 'Lỗi';
        statusBadge.className = 'status-badge error';
        resultContent.innerHTML = `
            <div class="error-message">
                <strong>Lỗi:</strong> ${escapeHtml(data.error || 'Có lỗi xảy ra')}
            </div>
        `;
    }
}

function displayCreateError(error) {
    const resultDiv = document.getElementById('create-result');
    resultDiv.innerHTML = `
        <div class="result-error">
            <h3>❌ Lỗi tạo thẻ đục lỗ</h3>
            <p>${escapeHtml(error)}</p>
        </div>
    `;
    resultDiv.style.display = 'block';
}

// Utility Functions
function escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}

// Initialize when DOM is loaded
document.addEventListener('DOMContentLoaded', function() {
    // Initialize character counter
    const textInput = document.getElementById('text-input');
    if (textInput) {
        textInput.addEventListener('input', updateCharCounter);
    }
    
    // File input
    const fileInput = document.getElementById('file-input');
    if (fileInput) {
        fileInput.addEventListener('change', handleFileSelect);
    }
    
    // Drag and drop functionality
    const uploadArea = document.getElementById('upload-area');
    if (uploadArea) {
        uploadArea.addEventListener('dragover', function(e) {
            e.preventDefault();
            this.classList.add('drag-over');
        });
        
        uploadArea.addEventListener('dragleave', function(e) {
            e.preventDefault();
            this.classList.remove('drag-over');
        });
        
        uploadArea.addEventListener('drop', function(e) {
            e.preventDefault();
            this.classList.remove('drag-over');
            
            const files = e.dataTransfer.files;
            if (files.length > 0) {
                const file = files[0];
                if (file.type.startsWith('image/')) {
                    selectedFile = file;
                    document.getElementById('file-name').textContent = file.name;
                    document.getElementById('file-selected').style.display = 'block';
                } else {
                    alert('Vui lòng chọn một tệp hình ảnh hợp lệ!');
                }
            }
        });
    }
}); 