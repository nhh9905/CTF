# Note patch
- Max 50 bytes changed
- Not change size of binary
- Not change program logic
- Patched file upload: chall.zip containing only one file named chall