#!/usr/bin/env python3

from pwn import *

# ENV
PORT = 1337
HOST = "35.197.152.52"
exe = context.binary = ELF('./chall_patched', checksec=False)
libc = ELF('./libc.so.6', checksec=False)
ld = ELF('./ld-linux-x86-64.so.2', checksec=False)

def GDB():
    if not args.r:
        gdb.attach(p, gdbscript='''
            source /home/nhh/pwndbg/gdbinit.py
            b* 0x0000000000401C53
            b* 0x0000000000401CDE
            c
            set follow-fork-mode parent
            ''')

if len(sys.argv) > 1 and sys.argv[1] == 'r':
    p = remote(HOST, PORT)
else:
    p = exe.process()


# VARIABLE


# PAYLOAD
p.sendline(b'REGISTER a')
p.sendline(b'AUTH a')
GDB()
p.sendline(b'UPLOAD abcdxyz')

p.interactive()