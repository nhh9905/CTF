#!/usr/bin/env python3
# -*- coding: utf-8 -*-
import os, re, json, time, hashlib, multiprocessing as mp
from itertools import count
from dataclasses import dataclass, asdict
from typing import Dict, List, Tuple, Optional
from pwn import *

# -------------------- cấu hình chung --------------------
context.arch = "amd64"
context.os   = "linux"
# context.log_level = "debug"   # bật khi cần soi I/O

HOST = os.getenv("HOST", "pwn4.cscv.vn")
PORT = int(os.getenv("PORT", "9999"))
BIN  = os.getenv("BIN", "./quiz")     # dùng khi chạy LOCAL/GDB
TARGET_UNIQUE = int(os.getenv("TARGET", "100"))  # số câu muốn thu

QUESTIONS_TXT = "questions.txt"
QA_JSON       = "qa_db.json"

# -------------------- kiểu dữ liệu ----------------------
@dataclass
class QuestionItem:
    question: str
    options: List[str]               # 4 lựa chọn
    correct_idx: Optional[int] = None  # 1..4 nếu đã biết
    tried_wrong: List[int] = None      # danh sách chỉ mục 1..4 đã thử sai

    def to_json(self):
        return {
            "question": self.question,
            "options": self.options,
            "correct_idx": self.correct_idx,
            "tried_wrong": self.tried_wrong or [],
        }

    @staticmethod
    def from_json(d):
        return QuestionItem(
            question=d["question"],
            options=d["options"],
            correct_idx=d.get("correct_idx"),
            tried_wrong=d.get("tried_wrong", []),
        )

# -------------------- util lưu/đọc DB -------------------
def norm_text(s: str) -> str:
    # chuẩn hóa key câu hỏi để tránh trùng lặp do khoảng trắng
    return re.sub(r"\s+", " ", s.strip())

def load_db() -> Dict[str, QuestionItem]:
    if not os.path.exists(QA_JSON):
        return {}
    with open(QA_JSON, "r", encoding="utf-8") as f:
        raw = json.load(f)
    db = {}
    for k, v in raw.items():
        db[k] = QuestionItem.from_json(v)
    return db

def save_db(db: Dict[str, QuestionItem]):
    # ghi json
    with open(QA_JSON, "w", encoding="utf-8") as f:
        json.dump({k: v.to_json() for k, v in db.items()}, f, ensure_ascii=False, indent=2)
    # ghi txt (đẹp, dễ đọc)
    lines = []
    for k, item in sorted(db.items(), key=lambda kv: kv[0]):
        lines.append("-----")
        lines.append(item.question.strip())
        for i, opt in enumerate(item.options, start=1):
            lines.append(f"{i}. {opt}")
        if item.correct_idx:
            lines.append(f"Correct: {item.correct_idx} - {item.options[item.correct_idx-1]}")
        else:
            tried = ",".join(map(str, item.tried_wrong or [])) if (item.tried_wrong) else ""
            lines.append(f"Correct: ?   (tried wrong: {tried})")
        lines.append("")
    with open(QUESTIONS_TXT, "w", encoding="utf-8") as f:
        f.write("\n".join(lines))

# -------------------- PoW solver (kế thừa, tinh gọn) ----
def _solve_pow_single(challenge: bytes, zeros: int) -> str:
    target = "0" * zeros
    pref = challenge
    for i in count():
        x = str(i).encode()
        if hashlib.sha256(pref + x).hexdigest().startswith(target):
            return x.decode()

def _worker_mp(challenge: bytes, zeros: int, start: int, step: int, found_q: mp.Queue, stop_ev: mp.Event):
    target = "0" * zeros
    i = start
    while not stop_ev.is_set():
        x = str(i).encode()
        if hashlib.sha256(challenge + x).hexdigest().startswith(target):
            found_q.put(x.decode())
            stop_ev.set()
            return
        i += step

def solve_pow(challenge: bytes, zeros: int = 6) -> str:
    procs = int(os.getenv("POW_PROCS", "1"))
    if procs <= 1:
        return _solve_pow_single(challenge, zeros)
    found_q, stop_ev = mp.Queue(), mp.Event()
    ps = [mp.Process(target=_worker_mp, args=(challenge, zeros, s, procs, found_q, stop_ev)) for s in range(procs)]
    for p in ps: p.start()
    ans = found_q.get()
    stop_ev.set()
    for p in ps:
        p.join(timeout=0.1)
        if p.is_alive():
            p.terminate()
    return ans

def parse_zeros_from_banner(banner: bytes, default_zeros: int = 6) -> int:
    m = re.search(rb"starts\s+with\s+(\d+)\s+zero", banner, re.I)
    if m:
        try:
            return int(m.group(1).decode())
        except Exception:
            pass
    return default_zeros

# -------------------- giao tiếp app ---------------------
def connect_and_pow() -> tube:
    if args.LOCAL:
        p = process([BIN])
    elif args.GDB:
        p = gdb.debug([BIN], gdbscript="")
    else:
        p = remote(HOST, PORT)

        # Hứng banner đến "Challenge: "
        banner = b""
        p.recvuntil(b"Challenge: ")
        challenge = p.recvline().strip()
        banner += b"Challenge: " + challenge + b"\n"

        # Hứng thêm vài dòng (non-blocking nhẹ)
        orig_to = p.timeout
        p.timeout = 0.2
        try:
            while True:
                line = p.recvline(timeout=0.1)
                if not line:
                    break
                banner += line
                if b"Enter your answer" in line:
                    break
        except Exception:
            pass
        finally:
            p.timeout = orig_to

        zeros = parse_zeros_from_banner(banner, 6)
        log.info(f"hash_challenge: {challenge.decode()}")
        log.info(f"Difficulty: need SHA256(challenge + X) starts with {zeros} zero(s)")

        t0 = time.time()
        X = solve_pow(challenge, zeros=zeros)
        took = time.time() - t0
        log.success(f"PoW solved: X='{X}' in {took:.2f}s")
        h = hashlib.sha256(challenge + X.encode()).hexdigest()
        log.info(f"SHA256('{challenge.decode()}' + '{X}') = {h[:32]}...")

        p.sendlineafter(b"Enter your answer:", X.encode())

    return p

def create_player(p: tube, name: bytes):
    # Vào menu 1 và nhập tên
    p.sendlineafter(b">", b"1")
    p.sendlineafter(b"Enter your name:", name)

def go_start_quiz(p: tube):
    # Chọn menu 3 để bắt đầu quiz
    p.sendlineafter(b">", b"3")
    # Đợi tiêu đề quiz xuất hiện (best-effort)
    try:
        p.recvuntil(b"=== QUIZ", timeout=5)
    except Exception:
        pass

def recv_until_question_header(p: tube, timeout=10) -> bool:
    """
    Chờ tới dòng bắt đầu 1 câu hỏi: '--- Question X ---'
    Trả về True nếu thấy, False nếu rơi về menu hoặc EOF.
    """
    # dùng recvuntil với pattern '--- Question ' để đồng bộ
    try:
        p.recvuntil(b"--- Question ", timeout=timeout)
        # Ăn nốt phần còn lại của dòng số câu
        _ = p.recvline(timeout=2)
        return True
    except EOFError:
        return False
    except Exception:
        return False

def read_question_block(p: tube) -> Optional[Tuple[str, List[str]]]:
    """
    Sau khi đã thấy header '--- Question ... ---',
    đọc phần question text + 4 option. Trả về (question_text, [opt1..opt4]).
    """
    q_lines: List[str] = []
    opts: List[str] = []
    # Đọc cho đến khi gom đủ 4 option (1..4)
    # giữa chừng có thể có dòng rỗng
    # Khi đủ 4 option, sẽ có prompt '>' để nhập đáp án
    while True:
        line = p.recvline(timeout=5)
        if not line:
            return None
        s = line.decode(errors="ignore").strip()
        if re.match(r"^[1-4]\.\s", s):
            # Option line
            # đảm bảo đúng thứ tự 1..4
            opts.append(re.sub(r"^[1-4]\.\s*", "", s))
            if len(opts) == 4:
                # ăn prompt '>' (nếu hiện ngay)
                try:
                    # có thể là '> ' hoặc '> $ ' — dùng recvuntil('>') là đủ
                    p.recvuntil(b">", timeout=3)
                except Exception:
                    pass
                break
        else:
            # các dòng thuộc phần câu hỏi
            # bỏ qua các heading/trang trí thừa
            if s and not s.startswith("Welcome ") and not s.startswith("Answer the questions"):
                # loại trừ các banner phụ
                q_lines.append(s)

    # ghép câu hỏi (nhiều dòng -> 1 dòng)
    question = " ".join(q_lines).strip()
    return (question, opts)

def send_answer(p: tube, idx: int):
    assert 1 <= idx <= 4
    p.sendline(str(idx).encode())

def read_feedback(p: tube, timeout=5) -> Optional[bool]:
    """
    Đọc phản hồi sau khi gửi đáp án.
    Trả về True nếu 'Correct!', False nếu 'Wrong!', None nếu không bắt được.
    """
    end_time = time.time() + timeout
    buf = b""
    while time.time() < end_time:
        try:
            chunk = p.recv(timeout=0.5)
            if not chunk:
                continue
            buf += chunk
            s = buf.decode(errors="ignore")
            if "Correct!" in s:
                return True
            if "Wrong!" in s:
                return False
            # Nếu đã in header câu hỏi tiếp theo thì coi như feedback chưa kịp match,
            # nhưng thường server sẽ in 'Correct!'/'Wrong!' trước rồi mới tới câu tiếp.
            if "--- Question" in s:
                # đẩy lại vào buffer nội bộ của pwntools là phức tạp;
                # ở đây đơn giản chỉ return None (hiếm khi xảy ra).
                return None
        except EOFError:
            return None
        except Exception:
            pass
    return None

# -------------------- chiến lược chọn đáp án --------------
def pick_choice_for_unknown(item: QuestionItem) -> int:
    tried = set(item.tried_wrong or [])
    for idx in [1, 2, 3, 4]:
        if idx not in tried:
            return idx
    # nếu đã thử cả 4 mà chưa biết correct (trường hợp bất thường), cứ trả 1
    return 1

# -------------------- vòng lặp chính ----------------------
def main():
    db: Dict[str, QuestionItem] = load_db()
    log.info(f"Loaded DB: {len(db)} known questions")

    collected = sum(1 for v in db.values() if v.correct_idx)
    log.info(f"Already solved (know correct answer): {collected}")

    while True:
        if len(db) >= TARGET_UNIQUE and all(v.correct_idx for v in db.values()):
            log.success(f"Reached target ~{TARGET_UNIQUE} questions (or all known). Stop.")
            break

        p = connect_and_pow()

        try:
            # Tạo player ngẫu nhiên để tránh xung đột
            name = f"nig_{int(time.time())%100000}".encode()
            create_player(p, name)
            go_start_quiz(p)

            # vòng trong: đọc liên tục câu hỏi
            while True:
                got_header = recv_until_question_header(p, timeout=8)
                if not got_header:
                    # có thể rớt về menu hoặc kết thúc quiz
                    break

                blk = read_question_block(p)
                if not blk:
                    break
                q_text, options = blk
                key = norm_text(q_text)

                # nếu câu hỏi mới hoàn toàn, thêm vào DB
                if key not in db:
                    db[key] = QuestionItem(question=q_text.strip(), options=options[:], correct_idx=None, tried_wrong=[])
                    log.info(f"[NEW] {q_text[:80]}...")

                item = db[key]
                # đồng bộ options nếu server có version khác (phòng rủi ro)
                if len(item.options) == 4 and item.options != options:
                    # ưu tiên options mới nhất
                    item.options = options[:]

                if item.correct_idx:
                    # biết đáp án rồi -> trả lời luôn để không trừ quota
                    send_answer(p, item.correct_idx)
                    ok = read_feedback(p, timeout=5)
                    # nếu bất thường, cứ tiếp tục
                else:
                    # chưa biết -> thử một đáp án chưa từng sai
                    choice = pick_choice_for_unknown(item)
                    send_answer(p, choice)
                    ok = read_feedback(p, timeout=5)
                    if ok is True:
                        item.correct_idx = choice
                        log.success(f"[OK] Learned correct: {choice} for: {q_text[:80]}...")
                    elif ok is False:
                        # ghi nhận đã thử sai
                        if item.tried_wrong is None:
                            item.tried_wrong = []
                        if choice not in item.tried_wrong:
                            item.tried_wrong.append(choice)
                        log.warning(f"[WRONG] {choice} for: {q_text[:80]}...")
                    else:
                        log.warning("[?] Could not determine feedback this round.")

                # lưu DB + TXT mỗi câu để không mất dữ liệu nếu ngắt
                save_db(db)

                # điều kiện dừng mềm khi đạt mục tiêu số câu duy nhất (kể cả chưa biết đáp án hết)
                if len(db) >= TARGET_UNIQUE:
                    pass

            # trở lại menu chính thì đóng kết nối và mở session mới
            p.close()

        except KeyboardInterrupt:
            p.close()
            break
        except EOFError:
            try:
                p.close()
            except Exception:
                pass
        except Exception as ex:
            log.exception(ex)
            try:
                p.close()
            except Exception:
                pass

    log.success(f"Done. Questions saved to {QUESTIONS_TXT} and {QA_JSON}")

if __name__ == "__main__":
    main()
