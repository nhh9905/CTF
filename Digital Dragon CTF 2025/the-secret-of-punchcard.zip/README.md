# DDC Punch card

## BUILD
```
$ sudo docker compose up --build -d
```

## TEST
```
$ curl -Ik http://localhost:5000

```