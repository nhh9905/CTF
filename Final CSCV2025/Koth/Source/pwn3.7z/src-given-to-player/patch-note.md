How to patch:
- Patch binary chall to prevent other's exploit and compress into patch.zip

- Structure:
───patch.zip
     └───chall

- Rule:
    - Patch bytes maximum is 25 bytes
    - Over 25 bytes -> fail
    - Program run unexpectedly -> fail