from flask import Flask, render_template, request, jsonify, send_file
import os
import numpy as np
from PIL import Image, ImageDraw
import json
import base64
import socket
import io
import time


PUNCHCARD_HOST = os.getenv('PUNCHCARD_HOST', 'pwn-easy-bin')
PUNCHCARD_PORT = int(os.getenv('PUNCHCARD_PORT', '1337'))

app = Flask(__name__)
app.config['UPLOAD_FOLDER'] = 'uploads'
app.config['MAX_CONTENT_LENGTH'] = 16 * 1024 * 1024  


os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)

ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg', 'bmp', 'tiff'}

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

def create_visual_punch_card(punch_data):
    """
    Create a visual representation of the punch card using template.png
    """
    try:
        
        template_img = Image.open('templates/template.png')
        
        
        if template_img.mode == 'RGBA':
            rgb_img = Image.new('RGB', template_img.size, (255, 255, 255))
            rgb_img.paste(template_img, mask=template_img.split()[-1])
            template_img = rgb_img
        
        
        img = template_img.copy()
        draw = ImageDraw.Draw(img)
        
        
        
        first_col_x = 27
        col_spacing = 9
        
        row_0_y = 26 #72   
        row_spacing = 26.7
        
        
        hole_width = 6
        hole_height = 12
        
        
        row_y_positions = {
            0: row_0_y,      
            1: row_0_y + row_spacing,      
            2: row_0_y + 2 * row_spacing,       
            3: row_0_y + 3 * row_spacing,      
            4: row_0_y + 4 * row_spacing,  
            5: row_0_y + 5 * row_spacing,  
            6: row_0_y + 6 * row_spacing,  
            7: row_0_y + 7 * row_spacing,  
            8: row_0_y + 8 * row_spacing,  
            9: row_0_y + 9 * row_spacing,  
            10: row_0_y + 10 * row_spacing, 
            11: row_0_y + 11 * row_spacing, 
        }
        
        for col, punched_rows in punch_data.items():
            if isinstance(col, int) and 1 <= col <= 80:
                
                col_x = first_col_x + (col - 1) * col_spacing
                
                for row in punched_rows:
                    if 0 <= row < 12 and row in row_y_positions:
                        
                        row_y = row_y_positions[row]
                        
                        
                        x1 = int(col_x - hole_width // 2)
                        y1 = int(row_y - hole_height // 2)
                        x2 = int(col_x + hole_width // 2)
                        y2 = int(row_y + hole_height // 2)
                        
                        draw.rectangle([x1, y1, x2, y2], fill='white', outline='black')

        
        return img
        
    except Exception as e:
        print(f"Error using template: {e}")
        return 0
    
def read_raw_punch_data(image_path):
    """
    Read raw punch card data from image using exact positioning
    Returns: dict in format {column: [list of punched rows]}
    """
    try:
        
        img = Image.open(image_path)
        
        
        if img.mode == 'RGBA':
            rgb_img = Image.new('RGB', img.size, (255, 255, 255))
            rgb_img.paste(img, mask=img.split()[-1])
            img = rgb_img
        
        
        gray = img.convert('L')
        arr = np.array(gray)
        
        
        punch_data = detect_holes_with_exact_positioning(arr)
       
        return {
            'success': True,
            'punch_data': punch_data,
            'image_shape': arr.shape
        }
        
    except Exception as e:
        return {
            'success': False,
            'error': str(e)
        }

def detect_holes_with_exact_positioning(image_array):
    """
    Detect punch holes using exact positioning from create_visual_punch_card
    """
    punch_data = {}
    
    
    first_col_x = 27
    col_spacing = 9
    row_0_y = 26
    row_spacing = 26.7
    
    
    hole_width = 6
    hole_height = 12
    
    
    row_y_positions = {
        0: row_0_y,                          
        1: row_0_y + row_spacing,            
        2: row_0_y + 2 * row_spacing,        
        3: row_0_y + 3 * row_spacing,        
        4: row_0_y + 4 * row_spacing,        
        5: row_0_y + 5 * row_spacing,        
        6: row_0_y + 6 * row_spacing,        
        7: row_0_y + 7 * row_spacing,        
        8: row_0_y + 8 * row_spacing,        
        9: row_0_y + 9 * row_spacing,        
        10: row_0_y + 10 * row_spacing,      
        11: row_0_y + 11 * row_spacing,      
    }
    
    
    for col in range(1, 81):
        
        col_x = first_col_x + (col - 1) * col_spacing
        
        
        for row_idx in range(12):
            if row_idx in row_y_positions:
                row_y = row_y_positions[row_idx]
                
                
                x1 = int(col_x - hole_width // 2)
                y1 = int(row_y - hole_height // 2)
                x2 = int(col_x + hole_width // 2)
                y2 = int(row_y + hole_height // 2)
                
                
                height, width = image_array.shape
                x1 = max(0, min(x1, width - 1))
                y1 = max(0, min(y1, height - 1))
                x2 = max(0, min(x2, width - 1))
                y2 = max(0, min(y2, height - 1))
                
                if x2 > x1 and y2 > y1:
                    
                    roi = image_array[y1:y2, x1:x2]
                    
                    
                    if is_hole_present(roi):
                        if col not in punch_data:
                            punch_data[col] = []
                        punch_data[col].append(row_idx)
    
    
    for col in punch_data:
        punch_data[col].sort()
    
    return punch_data

def is_hole_present(roi):
    """
    Determine if a region of interest contains a punch hole
    """
    if roi.size == 0:
        return False
    
    
    white_pixels = np.sum(roi >= 240)   
    black_pixels = np.sum(roi <= 30)    
    gray_pixels = np.sum((roi > 30) & (roi < 240))  
    total_pixels = roi.size
    
    white_percentage = white_pixels / total_pixels
    black_percentage = black_pixels / total_pixels
    gray_percentage = gray_pixels / total_pixels

    if white_percentage > 0.5 and black_percentage > 0.15 and gray_percentage < 0.4:
        return True
    
    if roi.std() > 120 and white_percentage > 0.4:
        return True
    
    if roi.shape[0] >= 4 and roi.shape[1] >= 4:
        h, w = roi.shape
        center_h_start, center_h_end = h//4, 3*h//4
        center_w_start, center_w_end = w//4, 3*w//4
        
        center = roi[center_h_start:center_h_end, center_w_start:center_w_end]
        
        
        edges = np.concatenate([
            roi[0, :].flatten(),      
            roi[-1, :].flatten(),     
            roi[1:-1, 0].flatten(),   
            roi[1:-1, -1].flatten()   
        ])
        
        if center.size > 0 and edges.size > 0:
            center_avg = np.mean(center)
            edge_avg = np.mean(edges)
            
            
            if center_avg > edge_avg + 100 and center_avg > 200:
                return True
    
    return False


@app.route('/')
def index():
    return render_template('index.html')

@app.route('/create_punch_card', methods=['POST'])
def create_punch_card():
    try:
        data = request.get_json()
        text = data.get('text', '').strip()
        card_type = data.get('card_type', 'STANDARD')
        
        if not text:
            return jsonify({'error': 'No text provided'}), 400
        
        
        try:
            
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            sock.settimeout(10)  
            sock.connect((PUNCHCARD_HOST, PUNCHCARD_PORT))
             
            if card_type == 'STANDARD':
                request_data = b"create|STANDARD|" + text.encode('utf-8')
            elif card_type == 'IBM SYSTEM 360':
                request_data = b"create|IBM SYSTEM 360|" + text.encode('utf-8')
            else:
                return jsonify({'error': 'Invalid card type'}), 400
            
            
            sock.send(request_data)
            sock.shutdown(socket.SHUT_WR)  
            
            
            response_data = b""
            while True:
                chunk = sock.recv(8192)
                if not chunk:
                    break
                response_data += chunk
            try:
                
                response_str = response_data.decode('utf-8').strip()
                result = json.loads(response_str)

            except json.JSONDecodeError as e:
                return jsonify({'error': f'Invalid JSON response: {str(e)} - Output: {response_data}'}), 500
            
            if not result.get('success', False):
                return jsonify({'error': result.get('error', 'Unknown error from C service')}), 500
            
            punch_data = result.get('punch_data', {})
            
            
            punch_data_int = {}
            for col_str, rows in punch_data.items():
                punch_data_int[int(col_str)] = rows
            
            
            visual_card = create_visual_punch_card(punch_data_int)
            
            if visual_card and visual_card != 0:
                
                img_io = io.BytesIO()
                visual_card.save(img_io, 'PNG')
                img_io.seek(0)
                
                
                timestamp = str(int(time.time()))
                filename = f"punch_card_{timestamp}.png"
                temp_path = os.path.join('temp', filename)
                
                
                os.makedirs('temp', exist_ok=True)
                
                
                visual_card.save(temp_path)
                
                
                img_base64 = base64.b64encode(img_io.getvalue()).decode()
                
                return jsonify({
                    'success': True,
                    'text': text,
                    'card_type': card_type,
                    'visual_card': f'data:image/png;base64,{img_base64}',
                    'download_url': f'/download_punch_card/{filename}'
                })
            else:
                return jsonify({
                    'success': False,
                    'text': text,
                    'card_type': card_type,
                    'error': 'Could not create visual card'
                })
                
        except socket.error as e:
            return jsonify({'error': f'Connection to punchcard service failed: {str(e)}'}), 500
        except json.JSONDecodeError as e:
            return jsonify({'error': f'Invalid response from punchcard service: {str(e)}'}), 500
        except Exception as e:
            return jsonify({'error': f'Service communication error: {str(e)}'}), 500
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/download_punch_card/<filename>')
def download_punch_card(filename):
    """Download the created punch card image"""
    try:
        temp_path = os.path.join('temp', filename)
        
        if not os.path.exists(temp_path):
            return "File not found", 404
        
        
        safe_filename = f"punch_card_{filename.split('_')[-1]}"
        
        return send_file(
            temp_path, 
            mimetype='image/png',
            as_attachment=True,
            download_name=safe_filename
        )
        
    except Exception as e:
        return f"Error: {str(e)}", 500

@app.route('/read_punch_card', methods=['POST'])
def read_punch_card():
    """Read raw punch card data from uploaded image and send to C program via socket"""
    try:
        
        card_type = request.form.get('card_type', 'STANDARD')
        
        
        if 'image' in request.files:
            
            file = request.files['image']
            if file.filename == '':
                return jsonify({'error': 'No file selected'})
            
            image_path = 'uploads/punchcard_image_' + str(int(time.time())) + '.png'
            file.save(image_path)
        
        
        result = read_raw_punch_data(image_path)
        
        if os.path.exists(image_path):
            os.remove(image_path)

        if result['success']:
            punch_data = result['punch_data']
            
            
            data_to_send = json.dumps(punch_data)
            
            
            try:
                
                sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                sock.settimeout(10)  
                sock.connect((PUNCHCARD_HOST, PUNCHCARD_PORT))
                
                request_data = f"read|{card_type}|{data_to_send}"

                
                sock.send(request_data.encode('utf-8'))
                sock.shutdown(socket.SHUT_WR)  
                
                
                response_data = b""
                while True:
                    chunk = sock.recv(4096)
                    if not chunk:
                        break
                    response_data += chunk
                
                sock.close()
                
                try:
                    output = response_data.decode('utf-8').strip()
                except Exception as e:
                    return jsonify({'error': f"Error decoding response: {str(e)} - Output: {response_data}"})
                
            except socket.error as e:
                return jsonify({'error': f"Socket connection error: {str(e)}"})
            except Exception as e:
                return jsonify({'error': f"Communication error: {str(e)}"})
            

            return jsonify({
                'success': True,
                'card_type': card_type,    
                'output': output,
                'binary_format': card_type.upper() == 'IBM SYSTEM 360'
            })
        else:
            return jsonify(result)   

    except Exception as e:
        return jsonify({'error': f'Processing error: {str(e)}'})

if __name__ == '__main__':
    
    app.run(debug=True, host='0.0.0.0', port=5000, threaded=True) 